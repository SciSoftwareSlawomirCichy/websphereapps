package com.ibm.ejs.container;

import com.ibm.CORBA.iiop.ClientDelegate;
import com.ibm.ejs.container.finder.FinderResultFactory;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.cpmi.ASNnameNotDefinedException;
import com.ibm.websphere.cpmi.ASNnameNotUniqueException;
import com.ibm.websphere.cpmi.EEXQueryInfo;
import com.ibm.websphere.cpmi.PMBeanInfo;
import com.ibm.websphere.cpmi.PMHomeInfo;
import com.ibm.websphere.cpmi.PersistenceManager;
import com.ibm.websphere.csi.BeanBundle;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSINoSuchObjectException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.EJBDynamicQueryHelper;
import com.ibm.websphere.csi.InconsistentAccessIntentException;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.Transaction.TransactionManagerFactory;
import com.ibm.ws.Transaction.UOWCoordinator;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.appprofile.accessintent.AIEJBMethodInfo;
import com.ibm.ws.appprofile.accessintent.EJBAccessIntent;
import com.ibm.ws.ejbpersistence.beanextensions.EJBChangeRecord;
import com.ibm.ws.ejbpersistence.cache.PMDataCacheEntry;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import com.ibm.ws.threadContext.EJSDeployedSupportAccessorImpl;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;
import javax.ejb.EJBException;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import javax.ejb.EnterpriseBean;
import javax.ejb.FinderException;
import javax.resource.cci.Connection;
import javax.resource.cci.IndexedRecord;
import javax.rmi.CORBA.Stub;
import javax.rmi.CORBA.Tie;
import javax.rmi.CORBA.Util;
import javax.transaction.Synchronization;

public class EJBDynamicQueryHelperImpl implements EJBDynamicQueryHelper, Synchronization {
	private static final TraceComponent tc = Tr.register(EJBDynamicQueryHelperImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl";
	EJSContainer ivContainer = null;
	private PersistenceManager ivPM = null;
	private EJBAccessIntent ivAIService = null;
	private EntityContainerTx ivContainerTx = null;
	private J2EEName ivJ2EEName = null;
	private EJSHome ivEJSHome = null;
	private AccessIntent ivAccessIntent = null;
	private PMBeanInfo ivPMBeanInfo = null;
	private EEXQueryInfo ivEEXQueryInfo = null;

	public EJBDynamicQueryHelperImpl(EJSContainer container, EntityHelperImpl entityHelper, PersistenceManager pm) {
		this.ivContainer = container;
		this.ivAIService = entityHelper.getEJBAccessIntent();
		this.ivPM = pm;
	}

	public final boolean isContainerTxActive() throws CSIException {
		return this.ivContainer.getCurrentTx() != null;
	}

	public void createContainerTx(J2EEName j2eeName, boolean remote) throws CSIException {
		CSIException ex = null;
		UOWCurrent uowCurrent = TransactionManagerFactory.getUOWCurrent();
		UOWCoordinator uowCoord = uowCurrent.getUOWCoord();
		if (uowCoord == null) {
			throw new CSIException("no transaction context");
		} else {
			EJSDeployedSupport s = null;
			EJSWrapperBase wrapper = null;
			byte mid = -5;

			try {
				EJSWrapperCommon wrapperCommon = this.ivContainer.getHomeWrapperCommon(j2eeName);
				if (remote) {
					wrapper = wrapperCommon.getRemoteWrapper();
				} else {
					wrapper = wrapperCommon.getLocalWrapper();
					mid = -4;
				}

				s = new EJSDeployedSupport();
				this.ivContainer.preInvoke((EJSWrapperBase) wrapper, mid, s, "ejbQuery:java.lang.String");
			} catch (Throwable var10) {
				FFDCFilter.processException(var10, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.createContainerTx", "168",
						this);
				ex = new CSIException("preinvoke failure", var10);
			}

			try {
				if (s != null) {
					if (wrapper != null) {
						this.ivContainer.postInvoke((EJSWrapperBase) wrapper, mid, s);
					}

					this.ivContainer.putEJSDeployedSupport(s);
				}
			} catch (Throwable var11) {
				FFDCFilter.processException(var11, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.createContainerTx", "183",
						this);
				if (s != null) {
					this.ivContainer.putEJSDeployedSupport(s);
				}

				if (ex != null) {
					ex = new CSIException("postInvokee failure", var11);
				}
			}

			if (ex != null) {
				throw ex;
			}
		}
	}

	public void beginDynamicQuery() throws CSIException, CSITransactionRolledbackException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "beginDynamicQuery");
		}

		try {
			if (this.ivContainerTx != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.exit(tc, "prior dynamic query has not been terminated");
				}

				throw new CSIException("must end prior dynamic query before beginning new query");
			}

			this.ivContainerTx = EntityHelperImpl.getCurrentTx(this.ivContainer);
			if (this.ivContainerTx == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.exit(tc, "no transaction context");
				}

				throw new CSIException("transaction context is required");
			}

			this.ivContainerTx.registerSynchronization(this);
		} catch (Throwable var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.beginDynamicQuery", "211",
					this);
			throw new CSIException("beginDyanmicQuery failed", var5);
		} finally {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "beginDynamicQuery");
			}

		}

	}

	public final J2EEName getJ2EEName(String asnName)
			throws ASNnameNotUniqueException, ASNnameNotDefinedException, CSIException {
		return this.ivPM.getJ2EEName(asnName);
	}

	public J2EEName getJ2EEName2(String asnName)
			throws ASNnameNotUniqueException, ASNnameNotDefinedException, CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getJ2EENameInCurrentModule", asnName);
		}

		J2EEName matchingJ2EEName = null;
		List j2eeNameList = this.ivPM.getJ2EENames(asnName);
		J2EEName[] j2eeNameArray = (J2EEName[]) ((J2EEName[]) j2eeNameList.toArray(new J2EEName[j2eeNameList.size()]));
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "J2EENames with this asnName", j2eeNameArray);
		}

		if (j2eeNameArray.length == 1) {
			matchingJ2EEName = j2eeNameArray[0];
		} else {
			if (j2eeNameArray.length <= 1) {
				throw new ASNnameNotDefinedException();
			}

			J2EEName currentModuleJ2EEName = EJSDeployedSupportAccessorImpl.getEJSDeployedSupportAccessor()
					.getEJSDeployedSupport().getComponentMetaData().getModuleMetaData().getJ2EEName();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "J2EEName of current module", currentModuleJ2EEName);
			}

			if (currentModuleJ2EEName == null) {
				throw new IllegalStateException();
			}

			String currentModuleAppName = currentModuleJ2EEName.getApplication();
			String currentModuleModName = currentModuleJ2EEName.getModule();

			for (int i = 0; i < j2eeNameArray.length; ++i) {
				if (j2eeNameArray[i].getModule().equals(currentModuleModName)
						&& j2eeNameArray[i].getApplication().equals(currentModuleAppName)) {
					if (matchingJ2EEName != null) {
						throw new ASNnameNotUniqueException(
								"Multiple J2EENames in current module with same abstract schema name");
					}

					matchingJ2EEName = j2eeNameArray[i];
				}
			}

			if (matchingJ2EEName == null) {
				throw new ASNnameNotUniqueException(
						"Multiple J2EENames (none in current module) with same abstract schema name");
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getJ2EENameInCurrentModule", matchingJ2EEName);
		}

		return matchingJ2EEName;
	}

	public final J2EEName getJ2EEName(Object ejbHome) throws CSIException {
		EJSWrapperBase wrapper = this.getHomeWrapper(ejbHome);
		return this.ivContainer.getJ2EEName(wrapper);
	}

	public void endDynamicQuery() throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "endDynamicQuery");
		}

		if (this.ivContainerTx != null) {
			this.ivAccessIntent = null;
			this.ivJ2EEName = null;
			this.ivEEXQueryInfo = null;
			this.ivEJSHome = null;
			this.ivPMBeanInfo = null;
			this.ivContainerTx = null;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "endDynamicQuery");
		}

	}

	public void flushCache() throws CSIException {
		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "flushCache called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else {
			try {
				this.ivContainerTx.flush();
			} catch (Throwable var2) {
				throw new CSIException("failure during flush prior to query", var2);
			}
		}
	}

	public void flushCache(J2EEName[] homeNames) throws CSIException {
		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "flushCache called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else if (homeNames == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "flushCache called null reference for homeNames");
			}

			throw new CSIException("non-null reference must be passed for homeNames");
		} else if (homeNames.length == 0) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "flushCache called with array length == 0");
			}

			throw new CSIException("homeNames.length must be > 0");
		} else {
			try {
				int numberOfHomes = false;
				int numberOfHomes = homeNames.length;
				PMHomeInfo[] queryHome = new PMHomeInfo[numberOfHomes];

				for (int i = 0; i < numberOfHomes; ++i) {
					queryHome[i] = this.ivPM.getPMHomeInfo(homeNames[i]);
				}

				BeanBundle[] beans = this.ivContainerTx.getEnlistedEntityBeans(queryHome);
				this.ivContainerTx.flush(beans);
				this.ivPM.flushDeferredOperation(this.ivContainerTx, queryHome);
			} catch (Throwable var5) {
				throw new CSIException("failure during flush prior to query", var5);
			}
		}
	}

	public int getLockType(J2EEName j2eeName) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getLockType", j2eeName);
		}

		int lockType = -1;
		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getLockType called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else if (this.ivAccessIntent == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getLockType called prior to setAccessIntent");
			}

			throw new CSIException("access intent not set");
		} else {
			ComponentMetaDataAccessorImpl cmdAccessor = null;
			boolean cmdPushed = false;

			int var5;
			try {
				if (this.ivJ2EEName != j2eeName) {
					this.initialize(j2eeName);
				}

				cmdAccessor = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor();
				cmdAccessor.beginContext(this.ivEJSHome.beanMetaData);
				cmdPushed = true;
				lockType = this.ivPMBeanInfo.getLockType(this.ivAccessIntent);
				var5 = lockType;
			} catch (CSIException var10) {
				FFDCFilter.processException(var10, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getLockType", "683",
						this);
				throw var10;
			} catch (Throwable var11) {
				FFDCFilter.processException(var11, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getLockType", "688",
						this);
				throw new CSIException("unable to get lock type", var11);
			} finally {
				if (cmdPushed) {
					cmdAccessor.endContext();
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getLockType", j2eeName + ", lockType = " + lockType);
				}

			}

			return var5;
		}
	}

	public EJBLocalObject getEJBLocalObject(IndexedRecord record, J2EEName j2eeName)
			throws InconsistentAccessIntentException, CSINoSuchObjectException, CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBLocalObject");
		}

		EJBLocalObject ejbRef = null;

		try {
			if (this.ivContainerTx == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.exit(tc, "getEJBLocalObject called with no transaction context");
				}

				throw new CSIException("dynamic query not active or transaction has ended");
			}

			if (this.ivAccessIntent == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBLocalObject called prior to setAccessIntent");
				}

				throw new CSIException("access intent not set");
			}

			if (this.ivJ2EEName != j2eeName) {
				this.initialize(j2eeName);
			}

			EJSWrapperCommon wCommon = this.getEJSWrapperCommon(record);
			ejbRef = wCommon.getLocalObject();
			this.ivContainerTx.cacheAccessIntent(wCommon.getBeanId(), this.ivAccessIntent);
		} catch (InconsistentAccessIntentException var5) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBLocalObject uncheckedException", var5);
			}

			throw new CSIException(var5.getMessage());
		} catch (IllegalStateException var6) {
			FFDCFilter.processException(var6, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBLocalObject", "823",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBLocalObject uncheckedException", var6);
			}

			throw new CSIException("Can not get EJBLocalObject using remote home, J2EEName is: " + j2eeName);
		} catch (CSIException var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBLocalObject", "832",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBLocalObject uncheckedException", var7);
			}

			throw var7;
		} catch (Throwable var8) {
			FFDCFilter.processException(var8, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBLocalObject", "841",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBLocalObject exception", var8);
			}

			throw new CSIException("unchecked exception", var8);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEJBLocalObject returning: " + ejbRef);
		}

		return ejbRef;
	}

	public EJBObject getEJBObject(IndexedRecord record, J2EEName j2eeName)
			throws InconsistentAccessIntentException, CSINoSuchObjectException, CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBObject");
		}

		EJSWrapper ejbRef = null;

		try {
			if (this.ivContainerTx == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.exit(tc, "getEJBObject called with no transaction context");
				}

				throw new CSIException("dynamic query not active or transaction has ended");
			}

			if (this.ivAccessIntent == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBObject called prior to setAccessIntent");
				}

				throw new CSIException("access intent not set");
			}

			if (this.ivJ2EEName != j2eeName) {
				this.initialize(j2eeName);
			}

			EJSWrapperCommon wCommon = this.getEJSWrapperCommon(record);
			ejbRef = wCommon.getRemoteWrapper();
			this.ivContainerTx.cacheAccessIntent(ejbRef.beanId, this.ivAccessIntent);
		} catch (InconsistentAccessIntentException var5) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBObject uncheckedException", var5);
			}

			throw new CSIException(var5.getMessage());
		} catch (IllegalStateException var6) {
			FFDCFilter.processException(var6, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBObject", "952", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBObject uncheckedException", var6);
			}

			throw new CSIException("Can not get EJBObject using local home, J2EEName is: " + j2eeName);
		} catch (CSIException var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBObject", "961", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBObject uncheckedException", var7);
			}

			throw var7;
		} catch (Throwable var8) {
			FFDCFilter.processException(var8, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBObject", "970", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBObject exception", var8);
			}

			throw new CSIException("unchecked exception", var8);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEJBObject returning: " + ejbRef);
		}

		return ejbRef;
	}

	private EJSWrapperCommon getEJSWrapperCommon(IndexedRecord record) throws CSINoSuchObjectException, CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJSWrapperCommon");
		}

		EJSWrapperCommon wCommon = null;

		try {
			Object pkey = this.ivEEXQueryInfo.getKey(record, this.ivContainerTx, this.ivAccessIntent);
			HomeRecord hr = (HomeRecord) this.ivPMBeanInfo.getHomeForKey(pkey, this.ivContainerTx);
			if (hr != null) {
				EJSHome home = hr.getHomeAndInitialize();
				BeanId beanId = new BeanId(home, (Serializable) pkey);
				wCommon = home.getWrapper(beanId);
			} else {
				wCommon = EntityHelperImpl.getBean_Common(this.ivEJSHome, this.ivContainerTx, pkey);
			}
		} catch (NoSuchElementException var11) {
			throw new CSINoSuchObjectException("record not found in resultset", var11);
		} catch (Throwable var12) {
			FFDCFilter.processException(var12, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJSWrapperCommon", "606",
					this);
			throw new CSIException("unable to get wrapper", var12);
		} finally {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJSWrapperCommon");
			}

		}

		return wCommon;
	}

	public Connection getConnection(J2EEName j2eeName) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getConnection", j2eeName);
		}

		ComponentMetaDataAccessorImpl cmdAccessor = null;
		boolean cmdPushed = false;

		Connection var4;
		try {
			if (this.ivContainerTx == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.exit(tc, "getConnection called with no transaction context");
				}

				throw new CSIException("dynamic query not active or transaction has ended");
			}

			if (this.ivAccessIntent == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.exit(tc, "getConnection called priot to setAccessIntent");
				}

				throw new CSIException("access intent not set");
			}

			if (this.ivJ2EEName != j2eeName) {
				this.initialize(j2eeName);
			}

			cmdAccessor = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor();
			cmdAccessor.beginContext(this.ivEJSHome.beanMetaData);
			cmdPushed = true;
			var4 = this.ivEEXQueryInfo.getConnection(this.ivContainerTx, this.ivAccessIntent);
		} catch (CSIException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getConnection", "1029", this);
			throw var9;
		} catch (Throwable var10) {
			FFDCFilter.processException(var10, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getConnection", "1034", this);
			throw new CSIException("unable to get connection", var10);
		} finally {
			if (cmdPushed) {
				cmdAccessor.endContext();
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getConnection", j2eeName);
			}

		}

		return var4;
	}

	public Object[] getMetadata(J2EEName j2eeName) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getMetaData", j2eeName);
		}

		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getMetaData called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else {
			ComponentMetaDataAccessorImpl cmdAccessor = null;
			boolean cmdPushed = false;

			Object[] var4;
			try {
				if (this.ivJ2EEName != j2eeName) {
					this.initialize(j2eeName);
				}

				cmdAccessor = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor();
				cmdAccessor.beginContext(this.ivEJSHome.beanMetaData);
				cmdPushed = true;
				var4 = this.ivPMBeanInfo.getMetadata();
			} catch (CSIException var9) {
				FFDCFilter.processException(var9, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getMetaData", "1113",
						this);
				throw var9;
			} catch (Throwable var10) {
				FFDCFilter.processException(var10, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getMetaData", "1118",
						this);
				throw new CSIException("unable to get lock type", var10);
			} finally {
				if (cmdPushed) {
					cmdAccessor.endContext();
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getMetaData", j2eeName);
				}

			}

			return var4;
		}
	}

	private EJSWrapperBase getHomeWrapper(Object home) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getHomeWrapper");
		}

		EJSWrapperBase wrapper = null;
		if (home instanceof EJSWrapperBase) {
			wrapper = (EJSWrapperBase) home;
		} else {
			try {
				Stub stub = (Stub) home;
				ClientDelegate delegate = (ClientDelegate) stub._get_delegate();
				if (EJSPlatformHelper.isZOS()) {
					wrapper = (EJSWrapperBase) delegate.getTarget();
				} else {
					Tie tie = (Tie) delegate.getTarget();
					wrapper = (EJSWrapperBase) tie.getTarget();
				}
			} catch (Throwable var6) {
				FFDCFilter.processException(var6, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getHomeWrapper", "772",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getHomeWrapper");
				}

				throw new CSIException("Unable to get target from stub", var6);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getHomeWrapper");
		}

		return wrapper;
	}

	public void setAccessIntent(J2EEName j2eeName) throws CSIException {
		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "setAccessIntent called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else {
			HomeRecord hr = (HomeRecord) this.ivPM.getPMHomeInfo(j2eeName);
			EJSHome home = hr.getHomeAndInitialize();
			EJBMethodInfoImpl[] marray = home.beanMetaData.methodInfos;
			if (marray == null) {
				marray = home.beanMetaData.localMethodInfos;
			}

			this.ivAccessIntent = this.ivAIService.getDynamicQueryAccessIntent((AIEJBMethodInfo) marray[0]);
		}
	}

	public void beforeCompletion() {
	}

	public void afterCompletion(int status) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			if (this.ivContainerTx != null) {
				Tr.entry(tc, "afterCompletion is aborting active dynamic query");
			} else {
				Tr.entry(tc, "afterCompletion - no active dynamic query");
			}
		}

		try {
			this.endDynamicQuery();
		} catch (CSIException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.endDynamicQuery", "873", this);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "afterCompletion");
		}

	}

	public Class getEJBPrimaryKeyClass(J2EEName j2eeName) {
		return this.ivContainer.getEJBPrimaryKeyClass(j2eeName);
	}

	public void flush(EJBChangeRecord record, List j2eeNames) throws CSIException {
		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "flush called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else {
			this.ivPM.flush(this.ivContainerTx, record, j2eeNames);
		}
	}

	public Class getConcreateBeanClass(J2EEName j2eeName) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getConcreateBeanClass: " + j2eeName.toString());
		}

		if (this.ivJ2EEName != j2eeName) {
			this.initialize(j2eeName);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getConcreateBeanClass returning: " + this.ivEJSHome.enterpriseBeanClass.getName());
		}

		return this.ivEJSHome.enterpriseBeanClass;
	}

	public Object executeFinder(J2EEName j2eeName, Method finder, Object[] methodArgs, boolean isLocal)
			throws FinderException, RemoteException, EJBException, CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "executeFinder: method name = " + finder.getName() + ", isLocal = " + isLocal + ", J2EEName = "
					+ j2eeName);
		}

		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "executeFinder called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else if (this.ivAccessIntent == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "executeFinder called prior to setAccessIntent");
			}

			throw new CSIException("access intent not set");
		} else {
			EJSDeployedSupport s = null;
			EntityBeanO beanO = null;
			int methodId = Integer.MAX_VALUE;
			Throwable ex = null;
			boolean checkedException = false;
			Object pkeys = null;
			EJSWrapperBase homeWrapper = null;
			Object remoteCookie = null;

			try {
				if (this.ivJ2EEName != j2eeName) {
					this.initialize(j2eeName);
				}

				EJSWrapperCommon wrapperCommon = this.ivContainer.getHomeWrapperCommon(j2eeName);
				if (isLocal) {
					homeWrapper = wrapperCommon.getLocalWrapper();
					methodId = -4;
				} else {
					EJSWrapper remoteWrapper = wrapperCommon.getRemoteWrapper();
					homeWrapper = remoteWrapper;
					methodId = -5;
					org.omg.CORBA.Object tie = (org.omg.CORBA.Object) Util.getTie(remoteWrapper);
					remoteCookie = this.ivContainer.preInvokeORBDispatch(tie, finder.getName());
				}

				s = new EJSDeployedSupport();
				this.ivContainer.preInvoke((EJSWrapperBase) homeWrapper, methodId, s);
				beanO = this.ivEJSHome.getFinderEntityBeanO();
				EnterpriseBean bean = beanO.getEnterpriseBean();
				pkeys = finder.invoke(bean, methodArgs);
			} catch (InvocationTargetException var26) {
				ex = var26.getTargetException();
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "executeFinder caught InvocationTargetException caused by: ", ex);
				}

				Class throwableClass = ex.getClass();
				Class[] checkedExceptions = finder.getExceptionTypes();
				int n = checkedExceptions.length;

				for (int i = 0; i < n; ++i) {
					if (ex instanceof Exception && checkedExceptions[i].isAssignableFrom(throwableClass)
							&& (!ContainerProperties.DeclaredUncheckedAreSystemExceptions
									|| !(ex instanceof RuntimeException))) {
						checkedException = true;
					}
				}

				if (checkedException) {
					s.setCheckedException((Exception) ex);
				} else {
					ex = this.setUncheckedException((Throwable) ex, s, isLocal);
				}
			} catch (CSIException var27) {
				FFDCFilter.processException((Throwable) ex, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.executeFinder",
						"1556", this);
				ex = var27;
			} catch (Throwable var28) {
				FFDCFilter.processException(var28, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.executeFinder", "1561",
						this);
				ex = new CSIException("executeFinder caught unexpected exception", var28);
			}

			if (beanO != null) {
				try {
					if (ex != null && !checkedException) {
						this.ivEJSHome.discardFinderEntityBeanO(beanO);
					} else {
						this.ivEJSHome.releaseFinderEntityBeanO(beanO);
					}
				} catch (Throwable var25) {
					FFDCFilter.processException(var25, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.executeFinder",
							"1582", this);
				}
			}

			if (s == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "executeFinder throwing CSIException");
				}

				if (ex != null && ex instanceof CSIException) {
					throw (CSIException) ex;
				} else {
					throw new CSIException("internal error, ex is either null or is not a CSIException",
							(Throwable) ex);
				}
			} else {
				Object var29;
				try {
					this.ivContainer.postInvoke((EJSWrapperBase) homeWrapper, methodId, s);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.exit(tc, "executeFinder returning collection of keys");
					}

					var29 = pkeys;
				} finally {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled() && pkeys == null) {
						Tr.exit(tc, "executeFinder threw exception");
					}

					this.ivContainer.putEJSDeployedSupport(s);
					if (remoteCookie != null) {
						this.ivContainer.postInvokeORBDispatch(remoteCookie);
					}

				}

				return var29;
			}
		}
	}

	private Throwable setUncheckedException(Throwable t, EJSDeployedSupport s, boolean isLocal) {
		Throwable tout = null;
		if (s == null) {
			this.ivContainerTx.setRollbackOnly();
			return t;
		} else {
			if (isLocal) {
				try {
					s.setUncheckedLocalException(t);
				} catch (EJBException var7) {
					tout = var7;
				}
			} else {
				try {
					s.setUncheckedException(t);
				} catch (RemoteException var6) {
					tout = var6;
				}
			}

			return (Throwable) tout;
		}
	}

	public Collection getEJBCollection(Collection keys, J2EEName j2eeName, boolean isLocal) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBCollection:  J2EEName = " + j2eeName.toString());
		}

		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getEJBCollection called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else if (this.ivAccessIntent == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBCollection called prior to setAccessIntent");
			}

			throw new CSIException("access intent not set");
		} else {
			try {
				if (this.ivJ2EEName != j2eeName) {
					this.initialize(j2eeName);
				}

				Collection result = FinderResultFactory.getCMP20FinderResultCollection(keys, this.ivEJSHome,
						this.ivContainerTx, this.ivAccessIntent, !isLocal);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBCollection returning collection of size " + result.size());
				}

				return result;
			} catch (CSIException var5) {
				FFDCFilter.processException(var5, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBCollection", "1753",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBCollection uncheckedException", var5);
				}

				throw var5;
			} catch (Throwable var6) {
				FFDCFilter.processException(var6, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBCollection", "1762",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBCollection exception", var6);
				}

				throw new CSIException("unchecked exception", var6);
			}
		}
	}

	public PMDataCacheEntry getDataCacheEntry(J2EEName j2eeName, Object key) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getDataCacheEntry:  J2EEName = " + j2eeName.toString());
		}

		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getDataCacheEntry called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else {
			PMDataCacheEntry result = null;

			try {
				if (this.ivJ2EEName != j2eeName) {
					this.initialize(j2eeName);
				}

				result = this.ivEEXQueryInfo.getDataCacheEntry(key, this.ivContainerTx);
			} catch (CSIException var5) {
				FFDCFilter.processException(var5, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getDataCacheEntry", "1807",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getDataCacheEntry uncheckedException", var5);
				}

				throw var5;
			} catch (Throwable var6) {
				FFDCFilter.processException(var6, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getDataCacheEntry", "1816",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getDataCacheEntry uncheckedException", var6);
				}

				throw new CSIException("unchecked exception", var6);
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getDataCacheEntry");
			}

			return result;
		}
	}

	public Collection getAssociatedKeys(String roleName, Object sourceKey, J2EEName j2eeName) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAssociatedKeys:  J2EEName = " + j2eeName + ", role name = " + roleName);
		}

		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getAssociatedKeys called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else {
			Collection result = null;

			try {
				if (this.ivJ2EEName != j2eeName) {
					this.initialize(j2eeName);
				}

				result = this.ivEEXQueryInfo.getAssociatedKeys(roleName, sourceKey, this.ivContainerTx);
			} catch (CSIException var6) {
				FFDCFilter.processException(var6, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getAssociatedKeys", "1869",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getAssociatedKeys uncheckedException", var6);
				}

				throw var6;
			} catch (Throwable var7) {
				FFDCFilter.processException(var7, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getAssociatedKeys", "1879",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getAssociatedKeys uncheckedException", var7);
				}

				throw new CSIException("unchecked exception", var7);
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getAssociatedKeys");
			}

			return result;
		}
	}

	public EJBLocalObject getEJBLocalObject(Object pkey, J2EEName j2eeName)
			throws InconsistentAccessIntentException, CSINoSuchObjectException, CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBLocalObject:  J2EEName = " + j2eeName);
		}

		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getEJBLocalObject called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else if (this.ivAccessIntent == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBLocalObject called prior to setAccessIntent");
			}

			throw new CSIException("access intent not set");
		} else {
			EJBLocalObject ejbRef = null;

			try {
				if (this.ivJ2EEName != j2eeName) {
					this.initialize(j2eeName);
				}

				EJSWrapperCommon wCommon = this.getEJSWrapperCommon(pkey);
				ejbRef = wCommon.getLocalObject();
				this.ivContainerTx.cacheAccessIntent(wCommon.getBeanId(), this.ivAccessIntent);
			} catch (InconsistentAccessIntentException var5) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBLocalObject uncheckedException", var5);
				}

				throw new CSIException(var5.getMessage());
			} catch (IllegalStateException var6) {
				FFDCFilter.processException(var6, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBLocalObject", "1955",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBLocalObject uncheckedException", var6);
				}

				throw new CSIException("Can not get EJBLocalObject using remote home, J2EEName is: " + j2eeName);
			} catch (CSIException var7) {
				FFDCFilter.processException(var7, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBLocalObject", "1964",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBLocalObject uncheckedException", var7);
				}

				throw var7;
			} catch (Throwable var8) {
				FFDCFilter.processException(var8, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBLocalObject", "1973",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBLocalObject exception", var8);
				}

				throw new CSIException("unchecked exception", var8);
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBLocalObject returning: " + ejbRef);
			}

			return ejbRef;
		}
	}

	public EJBObject getEJBObject(Object pkey, J2EEName j2eeName)
			throws InconsistentAccessIntentException, CSINoSuchObjectException, CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBObject:  J2EEName = " + j2eeName);
		}

		if (this.ivContainerTx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getEJBObject called with no transaction context");
			}

			throw new CSIException("dynamic query not active or transaction has ended");
		} else if (this.ivAccessIntent == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBObject called prior to setAccessIntent");
			}

			throw new CSIException("access intent not set");
		} else {
			EJSWrapper ejbRef = null;

			try {
				if (this.ivJ2EEName != j2eeName) {
					this.initialize(j2eeName);
				}

				EJSWrapperCommon wCommon = this.getEJSWrapperCommon(pkey);
				ejbRef = wCommon.getRemoteWrapper();
				this.ivContainerTx.cacheAccessIntent(ejbRef.beanId, this.ivAccessIntent);
			} catch (InconsistentAccessIntentException var5) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBObject uncheckedException", var5);
				}

				throw new CSIException(var5.getMessage());
			} catch (IllegalStateException var6) {
				FFDCFilter.processException(var6, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBObject", "2050",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBObject uncheckedException", var6);
				}

				throw new CSIException("Can not get EJBObject using local home, J2EEName is: " + j2eeName);
			} catch (CSIException var7) {
				FFDCFilter.processException(var7, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBObject", "2059",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBObject uncheckedException", var7);
				}

				throw var7;
			} catch (Throwable var8) {
				FFDCFilter.processException(var8, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJBObject", "2068",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBObject exception", var8);
				}

				throw new CSIException("unchecked exception", var8);
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJBObject returning: " + ejbRef);
			}

			return ejbRef;
		}
	}

	private EJSWrapperCommon getEJSWrapperCommon(Object pkey) throws CSINoSuchObjectException, CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJSWrapperCommon");
		}

		EJSWrapperCommon wCommon = null;

		try {
			HomeRecord hr = (HomeRecord) this.ivPMBeanInfo.getHomeForKey(pkey, this.ivContainerTx);
			if (hr != null) {
				EJSHome home = hr.getHomeAndInitialize();
				BeanId beanId = new BeanId(home, (Serializable) pkey);
				wCommon = home.getWrapper(beanId);
			} else {
				wCommon = EntityHelperImpl.getBean_Common(this.ivEJSHome, this.ivContainerTx, pkey);
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJSWrapperCommon");
			}

			return wCommon;
		} catch (RemoteException var6) {
			FFDCFilter.processException(var6, "com.ibm.ejs.csi.EJBDynamicQueryHelperImpl.getEJSWrapperCommon", "2129",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getEJSWrapperCommon failure", var6);
			}

			throw new CSIException("unable to get wrapper", var6);
		}
	}

	private void initialize(J2EEName j2eeName) throws CSIException {
		PMHomeInfo pmHomeInfo = this.ivPM.getPMHomeInfo(j2eeName);
		HomeRecord hr = (HomeRecord) pmHomeInfo;
		this.ivEJSHome = hr.getHomeAndInitialize();
		this.ivPMBeanInfo = pmHomeInfo.getPMBeanInfo();
		this.ivEEXQueryInfo = this.ivPMBeanInfo.getEEXQueryInfo();
		this.ivJ2EEName = j2eeName;
	}
}