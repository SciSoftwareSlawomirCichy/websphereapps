package com.google.common.math;

import javax.annotation.ParametersAreNonnullByDefault;

// $FF: synthetic class
@ParametersAreNonnullByDefault
interface package-info {
}