package com.google.inject.internal;

import com.google.inject.ConfigurationException;
import com.google.inject.CreationException;
import com.google.inject.Key;
import com.google.inject.MembersInjector;
import com.google.inject.Provider;
import com.google.inject.ProvisionException;
import com.google.inject.Scope;
import com.google.inject.TypeLiteral;
import com.google.inject.internal.Errors.1;
import com.google.inject.internal.Errors.2;
import com.google.inject.internal.Errors.3;
import com.google.inject.internal.Errors.4;
import com.google.inject.internal.Errors.Converter;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.InjectionListener;
import com.google.inject.spi.InjectionPoint;
import com.google.inject.spi.Message;
import com.google.inject.spi.TypeListenerBinding;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.Collections;
import java.util.Formatter;
import java.util.Iterator;
import java.util.List;

public final class Errors implements Serializable {
	private final Errors root;
	private final Errors parent;
	private final Object source;
	private List<Message> errors;
	private static final String CONSTRUCTOR_RULES = "Classes must have either one (and only one) constructor annotated with @Inject or a zero-argument constructor that is not private.";
	private static final Collection<Converter<?>> converters = ImmutableList.of(new 2(Class.class), new 3(Member.class), new 4(Key.class));

	public Errors() {
		this.root = this;
		this.parent = null;
		this.source = SourceProvider.UNKNOWN_SOURCE;
	}

	public Errors(Object source) {
		this.root = this;
		this.parent = null;
		this.source = source;
	}

	private Errors(Errors parent, Object source) {
		this.root = parent.root;
		this.parent = parent;
		this.source = source;
	}

	public Errors withSource(Object source) {
		return source == SourceProvider.UNKNOWN_SOURCE ? this : new Errors(this, source);
	}

	public Errors missingImplementation(Key key) {
		return this.addMessage("No implementation for %s was bound.", key);
	}

	public Errors converterReturnedNull(String stringValue, Object source, TypeLiteral<?> type,
			MatcherAndConverter matchingConverter) {
		return this.addMessage("Received null converting '%s' (bound at %s) to %s%n using %s.", stringValue,
				convert(source), type, matchingConverter);
	}

	public Errors conversionTypeError(String stringValue, Object source, TypeLiteral<?> type,
			MatcherAndConverter matchingConverter, Object converted) {
		return this.addMessage("Type mismatch converting '%s' (bound at %s) to %s%n using %s.%n Converter returned %s.",
				stringValue, convert(source), type, matchingConverter, converted);
	}

	public Errors conversionError(String stringValue, Object source, TypeLiteral<?> type,
			MatcherAndConverter matchingConverter, RuntimeException cause) {
		return this.errorInUserCode(cause, "Error converting '%s' (bound at %s) to %s%n using %s.%n Reason: %s",
				stringValue, convert(source), type, matchingConverter, cause);
	}

	public Errors ambiguousTypeConversion(String stringValue, Object source, TypeLiteral<?> type, MatcherAndConverter a,
			MatcherAndConverter b) {
		return this.addMessage(
				"Multiple converters can convert '%s' (bound at %s) to %s:%n %s and%n %s.%n Please adjust your type converter configuration to avoid overlapping matches.",
				stringValue, convert(source), type, a, b);
	}

	public Errors bindingToProvider() {
		return this.addMessage("Binding to Provider is not allowed.");
	}

	public Errors subtypeNotProvided(Class<? extends Provider<?>> providerType, Class<?> type) {
		return this.addMessage("%s doesn't provide instances of %s.", providerType, type);
	}

	public Errors notASubtype(Class<?> implementationType, Class<?> type) {
		return this.addMessage("%s doesn't extend %s.", implementationType, type);
	}

	public Errors recursiveImplementationType() {
		return this.addMessage("@ImplementedBy points to the same class it annotates.");
	}

	public Errors recursiveProviderType() {
		return this.addMessage("@ProvidedBy points to the same class it annotates.");
	}

	public Errors missingRuntimeRetention(Object source) {
		return this.addMessage("Please annotate with @Retention(RUNTIME).%n Bound at %s.", convert(source));
	}

	public Errors missingScopeAnnotation() {
		return this.addMessage("Please annotate with @ScopeAnnotation.");
	}

	public Errors optionalConstructor(Constructor constructor) {
		return this.addMessage("%s is annotated @Inject(optional=true), but constructors cannot be optional.",
				constructor);
	}

	public Errors cannotBindToGuiceType(String simpleName) {
		return this.addMessage("Binding to core guice framework type is not allowed: %s.", simpleName);
	}

	public Errors scopeNotFound(Class<? extends Annotation> scopeAnnotation) {
		return this.addMessage("No scope is bound to %s.", scopeAnnotation);
	}

	public Errors scopeAnnotationOnAbstractType(Class<? extends Annotation> scopeAnnotation, Class<?> type,
			Object source) {
		return this.addMessage(
				"%s is annotated with %s, but scope annotations are not supported for abstract types.%n Bound at %s.",
				type, scopeAnnotation, convert(source));
	}

	public Errors misplacedBindingAnnotation(Member member, Annotation bindingAnnotation) {
		return this.addMessage(
				"%s is annotated with %s, but binding annotations should be applied to its parameters instead.", member,
				bindingAnnotation);
	}

	public Errors missingConstructor(Class<?> implementation) {
		return this.addMessage(
				"Could not find a suitable constructor in %s. Classes must have either one (and only one) constructor annotated with @Inject or a zero-argument constructor that is not private.",
				implementation);
	}

	public Errors tooManyConstructors(Class<?> implementation) {
		return this.addMessage(
				"%s has more than one constructor annotated with @Inject. Classes must have either one (and only one) constructor annotated with @Inject or a zero-argument constructor that is not private.",
				implementation);
	}

	public Errors duplicateScopes(Scope existing, Class<? extends Annotation> annotationType, Scope scope) {
		return this.addMessage("Scope %s is already bound to %s. Cannot bind %s.", existing, annotationType, scope);
	}

	public Errors voidProviderMethod() {
		return this.addMessage("Provider methods must return a value. Do not return void.");
	}

	public Errors missingConstantValues() {
		return this.addMessage("Missing constant value. Please call to(...).");
	}

	public Errors cannotInjectInnerClass(Class<?> type) {
		return this.addMessage(
				"Injecting into inner classes is not supported.  Please use a 'static' class (top-level or nested) instead of %s.",
				type);
	}

	public Errors duplicateBindingAnnotations(Member member, Class<? extends Annotation> a,
			Class<? extends Annotation> b) {
		return this.addMessage("%s has more than one annotation annotated with @BindingAnnotation: %s and %s", member,
				a, b);
	}

	public Errors duplicateScopeAnnotations(Class<? extends Annotation> a, Class<? extends Annotation> b) {
		return this.addMessage("More than one scope annotation was found: %s and %s.", a, b);
	}

	public Errors recursiveBinding() {
		return this.addMessage("Binding points to itself.");
	}

	public Errors bindingAlreadySet(Key<?> key, Object source) {
		return this.addMessage("A binding to %s was already configured at %s.", key, convert(source));
	}

	public Errors childBindingAlreadySet(Key<?> key) {
		return this.addMessage("A binding to %s already exists on a child injector.", key);
	}

	public Errors errorInjectingMethod(Throwable cause) {
		return this.errorInUserCode(cause, "Error injecting method, %s", cause);
	}

	public Errors errorNotifyingTypeListener(TypeListenerBinding listener, TypeLiteral<?> type, Throwable cause) {
		return this.errorInUserCode(cause, "Error notifying TypeListener %s (bound at %s) of %s.%n Reason: %s",
				listener.getListener(), convert(listener.getSource()), type, cause);
	}

	public Errors errorInjectingConstructor(Throwable cause) {
		return this.errorInUserCode(cause, "Error injecting constructor, %s", cause);
	}

	public Errors errorInProvider(RuntimeException runtimeException) {
		return this.errorInUserCode(runtimeException, "Error in custom provider, %s", runtimeException);
	}

	public Errors errorInUserInjector(MembersInjector<?> listener, TypeLiteral<?> type, RuntimeException cause) {
		return this.errorInUserCode(cause, "Error injecting %s using %s.%n Reason: %s", type, listener, cause);
	}

	public Errors errorNotifyingInjectionListener(InjectionListener<?> listener, TypeLiteral<?> type,
			RuntimeException cause) {
		return this.errorInUserCode(cause, "Error notifying InjectionListener %s of %s.%n Reason: %s", listener, type,
				cause);
	}

	public void exposedButNotBound(Key<?> key) {
		this.addMessage("Could not expose() %s, it must be explicitly bound.", key);
	}

	public static Collection<Message> getMessagesFromThrowable(Throwable throwable) {
		if (throwable instanceof ProvisionException) {
			return ((ProvisionException) throwable).getErrorMessages();
		} else if (throwable instanceof ConfigurationException) {
			return ((ConfigurationException) throwable).getErrorMessages();
		} else {
			return (Collection) (throwable instanceof CreationException
					? ((CreationException) throwable).getErrorMessages()
					: ImmutableSet.of());
		}
	}

	public Errors errorInUserCode(Throwable cause, String messageFormat, Object... arguments) {
		Collection<Message> messages = getMessagesFromThrowable(cause);
		return !messages.isEmpty() ? this.merge(messages) : this.addMessage(cause, messageFormat, arguments);
	}

	public Errors cannotInjectRawProvider() {
		return this.addMessage("Cannot inject a Provider that has no type parameter");
	}

	public Errors cannotInjectRawMembersInjector() {
		return this.addMessage("Cannot inject a MembersInjector that has no type parameter");
	}

	public Errors cannotInjectTypeLiteralOf(Type unsupportedType) {
		return this.addMessage("Cannot inject a TypeLiteral of %s", unsupportedType);
	}

	public Errors cannotInjectRawTypeLiteral() {
		return this.addMessage("Cannot inject a TypeLiteral that has no type parameter");
	}

	public Errors cannotSatisfyCircularDependency(Class<?> expectedType) {
		return this.addMessage("Tried proxying %s to support a circular dependency, but it is not an interface.",
				expectedType);
	}

	public void throwCreationExceptionIfErrorsExist() {
		if (this.hasErrors()) {
			throw new CreationException(this.getMessages());
		}
	}

	public void throwConfigurationExceptionIfErrorsExist() {
		if (this.hasErrors()) {
			throw new ConfigurationException(this.getMessages());
		}
	}

	public void throwProvisionExceptionIfErrorsExist() {
		if (this.hasErrors()) {
			throw new ProvisionException(this.getMessages());
		}
	}

	private Message merge(Message message) {
		List<Object> sources = Lists.newArrayList();
		sources.addAll(this.getSources());
		sources.addAll(message.getSources());
		return new Message(sources, message.getMessage(), message.getCause());
	}

	public Errors merge(Collection<Message> messages) {
		Iterator i$ = messages.iterator();

		while (i$.hasNext()) {
			Message message = (Message) i$.next();
			this.addMessage(this.merge(message));
		}

		return this;
	}

	public Errors merge(Errors moreErrors) {
		if (moreErrors.root != this.root && moreErrors.root.errors != null) {
			this.merge((Collection) moreErrors.root.errors);
			return this;
		} else {
			return this;
		}
	}

	public List<Object> getSources() {
		List<Object> sources = Lists.newArrayList();

		for (Errors e = this; e != null; e = e.parent) {
			if (e.source != SourceProvider.UNKNOWN_SOURCE) {
				sources.add(0, e.source);
			}
		}

		return sources;
	}

	public void throwIfNewErrors(int expectedSize) throws ErrorsException {
		if (this.size() != expectedSize) {
			throw this.toException();
		}
	}

	public ErrorsException toException() {
		return new ErrorsException(this);
	}

	public boolean hasErrors() {
		return this.root.errors != null;
	}

	public Errors addMessage(String messageFormat, Object... arguments) {
		return this.addMessage((Throwable) null, messageFormat, arguments);
	}

	private Errors addMessage(Throwable cause, String messageFormat, Object... arguments) {
		String message = format(messageFormat, arguments);
		this.addMessage(new Message(this.getSources(), message, cause));
		return this;
	}

	public Errors addMessage(Message message) {
		if (this.root.errors == null) {
			this.root.errors = Lists.newArrayList();
		}

		this.root.errors.add(message);
		return this;
	}

	public static String format(String messageFormat, Object... arguments) {
		for (int i = 0; i < arguments.length; ++i) {
			arguments[i] = convert(arguments[i]);
		}

		return String.format(messageFormat, arguments);
	}

	public List<Message> getMessages() {
      if (this.root.errors == null) {
         return ImmutableList.of();
      } else {
         List<Message> result = Lists.newArrayList(this.root.errors);
         Collections.sort(result, new 1(this));
         return result;
      }
   }

	public static String format(String heading, Collection<Message> errorMessages) {
		Formatter fmt = (new Formatter()).format(heading).format(":%n%n");
		int index = 1;
		boolean displayCauses = getOnlyCause(errorMessages) == null;

		for (Iterator i$ = errorMessages.iterator(); i$.hasNext(); fmt.format("%n")) {
			Message errorMessage = (Message) i$.next();
			fmt.format("%s) %s%n", index++, errorMessage.getMessage());
			List<Object> dependencies = errorMessage.getSources();

			for (int i = dependencies.size() - 1; i >= 0; --i) {
				Object source = dependencies.get(i);
				formatSource(fmt, source);
			}

			Throwable cause = errorMessage.getCause();
			if (displayCauses && cause != null) {
				StringWriter writer = new StringWriter();
				cause.printStackTrace(new PrintWriter(writer));
				fmt.format("Caused by: %s", writer.getBuffer());
			}
		}

		if (errorMessages.size() == 1) {
			fmt.format("1 error");
		} else {
			fmt.format("%s errors", errorMessages.size());
		}

		return fmt.toString();
	}

	public <T> T checkForNull(T value, Object source, Dependency<?> dependency) throws ErrorsException {
		if (value == null && !dependency.isNullable()) {
			int parameterIndex = dependency.getParameterIndex();
			String parameterName = parameterIndex != -1 ? "parameter " + parameterIndex + " of " : "";
			this.addMessage("null returned by binding at %s%n but %s%s is not @Nullable", source, parameterName,
					dependency.getInjectionPoint().getMember());
			throw this.toException();
		} else {
			return value;
		}
	}

	public static Throwable getOnlyCause(Collection<Message> messages) {
		Throwable onlyCause = null;
		Iterator i$ = messages.iterator();

		while (i$.hasNext()) {
			Message message = (Message) i$.next();
			Throwable messageCause = message.getCause();
			if (messageCause != null) {
				if (onlyCause != null) {
					return null;
				}

				onlyCause = messageCause;
			}
		}

		return onlyCause;
	}

	public int size() {
		return this.root.errors == null ? 0 : this.root.errors.size();
	}

	public static Object convert(Object o) {
		Iterator i$ = converters.iterator();

		Converter converter;
		do {
			if (!i$.hasNext()) {
				return o;
			}

			converter = (Converter) i$.next();
		} while (!converter.appliesTo(o));

		return converter.convert(o);
	}

	public static void formatSource(Formatter formatter, Object source) {
		if (source instanceof Dependency) {
			Dependency<?> dependency = (Dependency) source;
			InjectionPoint injectionPoint = dependency.getInjectionPoint();
			if (injectionPoint != null) {
				formatInjectionPoint(formatter, dependency, injectionPoint);
			} else {
				formatSource(formatter, dependency.getKey());
			}
		} else if (source instanceof InjectionPoint) {
			formatInjectionPoint(formatter, (Dependency) null, (InjectionPoint) source);
		} else if (source instanceof Class) {
			formatter.format("  at %s%n", StackTraceElements.forType((Class) source));
		} else if (source instanceof Member) {
			formatter.format("  at %s%n", StackTraceElements.forMember((Member) source));
		} else if (source instanceof TypeLiteral) {
			formatter.format("  while locating %s%n", source);
		} else if (source instanceof Key) {
			Key<?> key = (Key) source;
			formatter.format("  while locating %s%n", convert(key));
		} else {
			formatter.format("  at %s%n", source);
		}

	}

	public static void formatInjectionPoint(Formatter formatter, Dependency<?> dependency,
			InjectionPoint injectionPoint) {
		Member member = injectionPoint.getMember();
		Class<? extends Member> memberType = MoreTypes.memberType(member);
		if (memberType == Field.class) {
			dependency = (Dependency) injectionPoint.getDependencies().get(0);
			formatter.format("  while locating %s%n", convert(dependency.getKey()));
			formatter.format("    for field at %s%n", StackTraceElements.forMember(member));
		} else if (dependency != null) {
			formatter.format("  while locating %s%n", convert(dependency.getKey()));
			formatter.format("    for parameter %s at %s%n", dependency.getParameterIndex(),
					StackTraceElements.forMember(member));
		} else {
			formatSource(formatter, injectionPoint.getMember());
		}

	}
}