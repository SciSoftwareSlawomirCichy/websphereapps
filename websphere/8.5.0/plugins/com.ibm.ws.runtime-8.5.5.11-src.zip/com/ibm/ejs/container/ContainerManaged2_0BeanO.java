package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.cpi.CPIException;
import com.ibm.websphere.cpmi.PMConcreteBean;
import com.ibm.websphere.cpmi.PMConcreteBeanInstanceInfo;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.InconsistentAccessIntentException;
import com.ibm.websphere.csi.PMTxInfo;
import com.ibm.websphere.csi.WSEntityContext;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EnterpriseBean;
import javax.ejb.NoSuchEntityException;

public class ContainerManaged2_0BeanO extends EntityBeanOImpl implements WSEntityContext {
	private static final TraceComponent tc = Tr.register(ContainerManaged2_0BeanO.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final TraceComponent tcClntInfo = Tr.register("WAS.clientinfopluslogging",
			"WAS.clientinfopluslogging", "com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.ContainerManaged2_0BeanO";
	protected PMConcreteBeanInstanceInfo ivPMBeanInfo = null;
	private final boolean isCleanEJBStoreEnabled;

	public ContainerManaged2_0BeanO(EJSContainer c, EnterpriseBean b, EJSHome h) {
		super(c, b, h);
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "ContainerManaged2_0BeanO.ctor : " + h.getJ2EEName());
		}

		try {
			this.ivPMBeanInfo = ((PMConcreteBean) b)._WSCB_getInstanceInfo();
			this.ivPMBeanInfo.setPMHomeInfo(EntityHelperImpl.getPMHomeInfo(h));
		} catch (Throwable var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.container.ContainerManaged2_0BeanO.ContainerManaged2_0BeanO",
					"168", this);
			ContainerEJBException ex = new ContainerEJBException("EJB failed to initialize. ", var7);
			Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var7, ex.toString()});
			throw ex;
		}

		this.isCleanEJBStoreEnabled = h.getBeanMetaData().isCleanEJBStoreEnabled;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "ContainerManaged2_0BeanO.ctor");
		}

	}

	public EnterpriseBean getEnterpriseBean() throws RemoteException {
		if (this.state != 1 && this.state != 13) {
			throw new InvalidBeanOStateException(this.stateStrs[this.state],
					this.stateStrs[1] + " | " + this.stateStrs[13]);
		} else {
			return this.entityBean;
		}
	}

	public synchronized void postCreate(boolean supportEjbPostCreateChanges) throws CreateException, RemoteException {
		this.dirty = true;
		this.setState(1, 2);
	}

	public final void store() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "store : " + this);
		}

		if (this.ivReadOnly) {
			if (this.discarded) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "store: Discarded ReadOnly Bean... marking tran for rollback");
				}

				this.container.getCurrentTx().setRollbackOnly();
			} else if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "store: ReadOnly Bean... no action");
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "store : " + this);
			}

		} else {
			if (!this.inCreate && !this.inStore && this.state != 8
					&& (this.isCleanEJBStoreEnabled || this.ivPMBeanInfo.isDirty())) {
				long pmiCookie = -1L;
				BeanOCallDispatchToken smfDispatchToken = null;
				int savedState = this.state;
				switch (this.state) {
					case 6 :
					case 7 :
						this.setState(10);
						this.inStore = true;

						try {
							if (this.pmiBean != null) {
								pmiCookie = this.pmiBean.storeTime();
							}

							if (isTraceOn) {
								if (tcClntInfo.isDebugEnabled()) {
									Tr.debug(tcClntInfo, "ejbStore");
								}

								if (TEBeanLifeCycleInfo.isTraceEnabled()) {
									TEBeanLifeCycleInfo.traceEJBCallEntry("ejbStore");
								}
							}

							if (isZOS) {
								smfDispatchToken = this.callDispatchEventListeners(8, (BeanOCallDispatchToken) null);
							}

							this.entityBean.ejbStore();
							if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
								TEBeanLifeCycleInfo.traceEJBCallExit("ejbStore");
							}
						} catch (RemoteException var14) {
							FFDCFilter.processException(var14, "com.ibm.ejs.container.ContainerManaged2_0BeanO.store",
									"177", this);
							this.destroy();
							pmiCookie = -1L;
							throw var14;
						} catch (NoSuchEntityException var15) {
							FFDCFilter.processException(var15, "com.ibm.ejs.container.ContainerManaged2_0BeanO.store",
									"182", this);
							this.destroy();
							pmiCookie = -1L;
							NoSuchObjectException nsoe = new NoSuchObjectException(var15.toString());
							nsoe.detail = var15;
							throw nsoe;
						} catch (EJBException var16) {
							FFDCFilter.processException(var16, "com.ibm.ejs.container.ContainerManaged2_0BeanO.store",
									"187", this);
							this.destroy();
							pmiCookie = -1L;
							throw var16;
						} catch (Exception var17) {
							FFDCFilter.processException(var17, "com.ibm.ejs.container.ContainerManaged2_0BeanO.store",
									"192", this);
							this.destroy();
							pmiCookie = -1L;
							throw new CPIException(var17);
						} finally {
							if (smfDispatchToken != null) {
								this.callDispatchEventListeners(9, smfDispatchToken);
							}

							if (pmiCookie != -1L) {
								this.pmiBean.storeTime(pmiCookie);
							}

							this.inStore = false;
						}

						this.setState(savedState);
						break;
					default :
						throw new InvalidBeanOStateException(this.stateStrs[this.state], "ACTIVE | IN_METHOD");
				}
			} else if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Not Storing: inCreate = " + this.inCreate + ", inStore = " + this.inStore, this);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "store : " + this);
			}

		}
	}

	public void preFind() throws RemoteException {
		this.setState(1, 13);
		this.beanId = null;
	}

	protected final void loadForEnlist(ContainerTx ctx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "ContainerManaged2_0BeanO.loadForEnlist");
		}

		long pmiCookie = -1L;
		int savedState = this.state;
		BeanOCallDispatchToken smfDispatchToken = null;

		try {
			if (this.pmiBean != null) {
				pmiCookie = this.pmiBean.loadTime();
			}

			if (isTraceOn && tcClntInfo.isDebugEnabled()) {
				Tr.debug(tcClntInfo, "ejbLoad");
			}

			this.setState(3);
			if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
				TEBeanLifeCycleInfo.traceEJBCallEntry("ejbLoad");
			}

			if (isZOS) {
				smfDispatchToken = this.callDispatchEventListeners(4, (BeanOCallDispatchToken) null);
			}

			this.entityBean.ejbLoad();
			if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
				TEBeanLifeCycleInfo.traceEJBCallExit("ejbLoad");
			}
		} catch (NoSuchEntityException var14) {
			pmiCookie = -1L;
			throw new NoSuchObjectException(var14.toString());
		} catch (RemoteException var15) {
			FFDCFilter.processException(var15, "com.ibm.ejs.container.ContainerManaged2_0BeanO.load", "321", this);
			pmiCookie = -1L;
			throw var15;
		} catch (EJBException var16) {
			FFDCFilter.processException(var16, "com.ibm.ejs.container.ContainerManaged2_0BeanO.load", "327", this);
			pmiCookie = -1L;
			throw var16;
		} catch (Exception var17) {
			FFDCFilter.processException(var17, "com.ibm.ejs.container.ContainerManaged2_0BeanO.load", "340", this);
			pmiCookie = -1L;
			throw new CPIException(var17);
		} finally {
			if (smfDispatchToken != null) {
				this.callDispatchEventListeners(5, smfDispatchToken);
			}

			if (this.state != 0) {
				this.setState(savedState);
			}

			if (pmiCookie != -1L) {
				this.pmiBean.loadTime(pmiCookie);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "ContainerManaged2_0BeanO.loadForEnlist");
			}

		}

	}

	protected final void load(ContainerTx tx, boolean forUpdate) throws RemoteException {
		this.loadForEnlist(tx);
	}

	public void enlistForOptionA(PMTxInfo tx) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "enlistForOptionA : notifying PM");
		}

		this.ivPMBeanInfo.enlistForOptionA(tx);
	}

	public String toString() {
		return "ContainerManaged2_0BeanO(" + this.beanId + ", state = " + StateStrs[this.state] + ")";
	}

	public PMTxInfo getCurrentPMTxInfo() {
		if (this.beanId != null && this.ivContainerTx != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getCurrentPMTxInfo : cached : " + this.ivContainerTx);
			}

			return (PMTxInfo) this.ivContainerTx;
		} else if (this.state != 13 && this.state != 1 && this.beanId == null) {
			throw new IllegalStateException("Method called when BeanId is null and not in finder/pooled method.");
		} else {
			ContainerTx tx = null;

			try {
				tx = this.container.getCurrentTx(false);
				if (tx != null) {
					this.ivContainerTx = tx;
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "getCurrentPMTxInfo : " + StateStrs[this.state] + " : " + this.ivContainerTx);
					}

					return (PMTxInfo) this.ivContainerTx;
				} else {
					throw new IllegalStateException("ContainerTx is null.");
				}
			} catch (Throwable var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.ContainerManaged2_0BeanO.getCurrentPMTxInfo",
						"372", this);
				throw new IllegalStateException("getCurrentTx Exception - " + var3.toString());
			}
		}
	}

	public boolean hasLocalInterface() {
		return this.home.localEJBObjectClass != null;
	}

	public final AccessIntent getAccessIntent() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAccessIntent");
		}

		if (this.ivAccessIntent == null) {
			if (this.ivContainerTx == null) {
				this.getCurrentPMTxInfo();
			}

			if (this.beanId != null) {
				EntityContainerTx entityContainerTx = this.getEntityContainerTx();
				this.ivAccessIntent = entityContainerTx.getCachedAccessIntent(this.beanId);
			}

			if (this.ivAccessIntent == null) {
				try {
					this.setAccessIntent();
					if (this.cachedExclusive && this.ivAccessIntent.getConcurrencyControl() == 2) {
						throw new EJBException("Optimistic concurrency not allowed with EJB commit option A");
					}
				} catch (InconsistentAccessIntentException var3) {
					FFDCFilter.processException(var3,
							"com.ibm.ejs.container.ContainerManaged2_0BeanO.ContainerManaged2_0BeanO", "531", this);
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "ContainerManaged2_0BeanO.getAccessIntent failure: " + var3.getMessage());
					}

					throw new EJBException("Unable to get access intent", var3);
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getAccessIntent");
		}

		return this.ivAccessIntent;
	}

	public void setAccessIntent(AccessIntent ai) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();

		try {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "setAccessIntent");
			}

			if (this.cachedExclusive && ai.getConcurrencyControl() == 2) {
				throw new EJBException("Optimistic concurrency not allowed with EJB commit option A");
			} else {
				if (this.home.hasMethodLevelAccessIntentSet()) {
					EntityContainerTx entityContainerTx = this.getEntityContainerTx();
					entityContainerTx.cacheAccessIntent(this.beanId, ai);
				}

				this.ivAccessIntent = ai;
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "setAccessIntent");
				}

			}
		} catch (InconsistentAccessIntentException var4) {
			FFDCFilter.processException(var4, "com.ibm.ejs.container.ContainerManaged2_0BeanO.setAccessIntent", "593",
					this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "setAccessIntent caught InconsistentAccessIntentException:" + var4.getMessage());
			}

			throw new CSIException(var4.getMessage());
		}
	}
}