package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.util.concurrent.JdkFutureAdapters.ListenableFutureAdapter;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;

@Beta
public final class JdkFutureAdapters {
	public static <V> ListenableFuture<V> listenInPoolThread(Future<V> future) {
		return (ListenableFuture) (future instanceof ListenableFuture
				? (ListenableFuture) future
				: new ListenableFutureAdapter(future));
	}

	public static <V> ListenableFuture<V> listenInPoolThread(Future<V> future, Executor executor) {
		Preconditions.checkNotNull(executor);
		return (ListenableFuture) (future instanceof ListenableFuture
				? (ListenableFuture) future
				: new ListenableFutureAdapter(future, executor));
	}
}