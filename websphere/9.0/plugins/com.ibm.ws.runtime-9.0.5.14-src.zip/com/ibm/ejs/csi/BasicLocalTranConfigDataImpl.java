package com.ibm.ejs.csi;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.dopriv.SystemGetPropertyPrivileged;
import com.ibm.tx.jta.embeddable.LocalTransactionSettings;
import com.ibm.websphere.csi.LocalTranConfigData;
import java.security.AccessController;

public class BasicLocalTranConfigDataImpl implements LocalTranConfigData, LocalTransactionSettings {
	private static final TraceComponent tc = Tr.register(BasicLocalTranConfigDataImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	protected int boundary = 0;
	protected int resolver = 0;
	protected int unresolvedAction = 0;
	protected boolean isShareable = false;

	public BasicLocalTranConfigDataImpl() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>");
		}

	}

	public BasicLocalTranConfigDataImpl(int resolver, int unresolvedAction) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> with resolver " + resolver + " and unresolvedAction " + unresolvedAction);
		}

		this.resolver = resolver;
		this.unresolvedAction = unresolvedAction;
	}

	public int getValueBoundary() {
		return this.boundary;
	}

	public int getBoundary() {
		return this.boundary;
	}

	public int getValueResolver() {
		return this.resolver;
	}

	public int getResolver() {
		return this.resolver;
	}

	public int getValueUnresolvedAction() {
		return this.unresolvedAction;
	}

	public int getUnresolvedAction() {
		return this.unresolvedAction;
	}

	public boolean isShareable() {
		return this.isShareable;
	}

	public String toString() {
		String separator = (String) AccessController
				.doPrivileged(new SystemGetPropertyPrivileged("line.separator", "\n"));
		String sep = "                                 ";
		StringBuffer sb = new StringBuffer();
		sb.append(separator).append(sep).append("      ****** LOCAL-TRANSACTION *******");
		sb.append(separator).append(sep).append("Boundary=");
		if (this.boundary == 1) {
			sb.append("ACTIVITY");
		} else if (this.boundary == 0) {
			sb.append("BEAN_METHOD");
		} else {
			sb.append("UNKNOWN");
		}

		sb.append(separator).append(sep).append("Resolver=");
		if (this.resolver == 0) {
			sb.append("APPLICATION");
		} else if (this.resolver == 1) {
			sb.append("CONTAINER_AT_BOUNDARY");
		} else {
			sb.append("UNKNOWN");
		}

		sb.append(separator).append(sep).append("UnResolvedAction=");
		if (this.unresolvedAction == 0) {
			sb.append("ROLLBACK");
		} else if (this.unresolvedAction == 1) {
			sb.append("COMMIT");
		} else {
			sb.append("UNKNOWN");
		}

		sb.append(separator).append(sep).append("isShareable=");
		if (this.isShareable) {
			sb.append("TRUE");
		} else {
			sb.append("FALSE");
		}

		return sb.toString();
	}
}