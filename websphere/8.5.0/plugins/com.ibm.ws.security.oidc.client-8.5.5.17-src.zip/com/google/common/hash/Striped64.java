package com.google.common.hash;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.hash.Striped64.1;
import com.google.common.hash.Striped64.Cell;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.Random;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;
import sun.misc.Unsafe;

@GwtIncompatible
abstract class Striped64 extends Number {
	static final ThreadLocal<int[]> threadHashCode = new ThreadLocal();
	static final Random rng = new Random();
	static final int NCPU = Runtime.getRuntime().availableProcessors();
	@NullableDecl
	transient volatile Cell[] cells;
	transient volatile long base;
	transient volatile int busy;
	private static final Unsafe UNSAFE;
	private static final long baseOffset;
	private static final long busyOffset;

	final boolean casBase(long cmp, long val) {
		return UNSAFE.compareAndSwapLong(this, baseOffset, cmp, val);
	}

	final boolean casBusy() {
		return UNSAFE.compareAndSwapInt(this, busyOffset, 0, 1);
	}

	abstract long fn(long var1, long var3);

	final void retryUpdate(long x, @NullableDecl int[] hc, boolean wasUncontended) {
		int h;
		if (hc == null) {
			threadHashCode.set(hc = new int[1]);
			int r = rng.nextInt();
			h = hc[0] = r == 0 ? 1 : r;
		} else {
			h = hc[0];
		}

		boolean collide = false;

		while (true) {
			Cell[] as = this.cells;
			int n;
			long v;
			if (this.cells != null && (n = as.length) > 0) {
				Cell a;
				if ((a = as[n - 1 & h]) == null) {
					if (this.busy == 0) {
						Cell r = new Cell(x);
						if (this.busy == 0 && this.casBusy()) {
							boolean created = false;

							try {
								Cell[] rs = this.cells;
								int m;
								int j;
								if (this.cells != null && (m = rs.length) > 0 && rs[j = m - 1 & h] == null) {
									rs[j] = r;
									created = true;
								}
							} finally {
								this.busy = 0;
							}

							if (created) {
								break;
							}
							continue;
						}
					}

					collide = false;
				} else if (!wasUncontended) {
					wasUncontended = true;
				} else {
					if (a.cas(v = a.value, this.fn(v, x))) {
						break;
					}

					if (n < NCPU && this.cells == as) {
						if (!collide) {
							collide = true;
						} else if (this.busy == 0 && this.casBusy()) {
							try {
								if (this.cells == as) {
									Cell[] rs = new Cell[n << 1];

									for (int i = 0; i < n; ++i) {
										rs[i] = as[i];
									}

									this.cells = rs;
								}
							} finally {
								this.busy = 0;
							}

							collide = false;
							continue;
						}
					} else {
						collide = false;
					}
				}

				h ^= h << 13;
				h ^= h >>> 17;
				h ^= h << 5;
				hc[0] = h;
			} else if (this.busy == 0 && this.cells == as && this.casBusy()) {
				boolean init = false;

				try {
					if (this.cells == as) {
						Cell[] rs = new Cell[2];
						rs[h & 1] = new Cell(x);
						this.cells = rs;
						init = true;
					}
				} finally {
					this.busy = 0;
				}

				if (init) {
					break;
				}
			} else if (this.casBase(v = this.base, this.fn(v, x))) {
				break;
			}
		}

	}

	final void internalReset(long initialValue) {
		Cell[] as = this.cells;
		this.base = initialValue;
		if (as != null) {
			int n = as.length;

			for (int i = 0; i < n; ++i) {
				Cell a = as[i];
				if (a != null) {
					a.value = initialValue;
				}
			}
		}

	}

	private static Unsafe getUnsafe() {
      try {
         return Unsafe.getUnsafe();
      } catch (SecurityException var2) {
         try {
            return (Unsafe)AccessController.doPrivileged(new 1());
         } catch (PrivilegedActionException var1) {
            throw new RuntimeException("Could not initialize intrinsics", var1.getCause());
         }
      }
   }

	static {
		try {
			UNSAFE = getUnsafe();
			Class<?> sk = Striped64.class;
			baseOffset = UNSAFE.objectFieldOffset(sk.getDeclaredField("base"));
			busyOffset = UNSAFE.objectFieldOffset(sk.getDeclaredField("busy"));
		} catch (Exception var1) {
			throw new Error(var1);
		}
	}
}