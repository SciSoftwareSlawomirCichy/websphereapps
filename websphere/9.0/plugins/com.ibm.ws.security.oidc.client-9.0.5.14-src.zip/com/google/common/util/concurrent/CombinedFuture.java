package com.google.common.util.concurrent;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.ImmutableCollection;
import com.google.common.util.concurrent.CombinedFuture.AsyncCallableInterruptibleTask;
import com.google.common.util.concurrent.CombinedFuture.CallableInterruptibleTask;
import com.google.common.util.concurrent.CombinedFuture.CombinedFutureRunningState;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

@GwtCompatible
final class CombinedFuture<V> extends AggregateFuture<Object, V> {
	CombinedFuture(ImmutableCollection<? extends ListenableFuture<?>> futures, boolean allMustSucceed,
			Executor listenerExecutor, AsyncCallable<V> callable) {
		this.init(new CombinedFutureRunningState(this, futures, allMustSucceed,
				new AsyncCallableInterruptibleTask(this, callable, listenerExecutor)));
	}

	CombinedFuture(ImmutableCollection<? extends ListenableFuture<?>> futures, boolean allMustSucceed,
			Executor listenerExecutor, Callable<V> callable) {
		this.init(new CombinedFutureRunningState(this, futures, allMustSucceed,
				new CallableInterruptibleTask(this, callable, listenerExecutor)));
	}
}