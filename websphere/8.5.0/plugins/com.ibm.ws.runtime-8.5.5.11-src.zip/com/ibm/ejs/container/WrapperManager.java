package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ByteArray;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.cache.Cache;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CacheElement;
import com.ibm.websphere.csi.DiscardException;
import com.ibm.websphere.csi.DiscardStrategy;
import com.ibm.websphere.csi.EJBCache;
import com.ibm.websphere.csi.EJBServantManager;
import com.ibm.websphere.csi.FaultException;
import com.ibm.websphere.csi.FaultStrategy;
import com.ibm.websphere.csi.IllegalOperationException;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.ejbcontainer.EJBOAKeyImpl;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import com.ibm.ws.ejbcontainer.diagnostics.TrDumpWriter;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;
import java.util.Enumeration;

public final class WrapperManager implements DiscardStrategy, FaultStrategy, EJBServantManager {
	private static final TraceComponent tc = Tr.register(WrapperManager.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.WrapperManager";
	protected EJBCache wrapperCache;
	private EJSContainer container;
	protected BeanIdCache beanIdCache;

	public WrapperManager(EJSContainer container) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "WrapperManager");
		}

		this.wrapperCache = container.wrapperCache;
		this.wrapperCache.setDiscardStrategy(this);
		this.wrapperCache.setFaultStrategy(this);
		this.container = container;
		int beanIdCacheSize = this.getBeanIdCacheSize(this.wrapperCache.getNumBuckets());
		this.beanIdCache = new BeanIdCache(beanIdCacheSize);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "WrapperManager");
		}

	}

	public void destroy() {
		this.wrapperCache = null;
		this.container = null;
	}

	public void setWrapperCacheSweepInterval(long interval) {
		this.wrapperCache.setSweepInterval(interval);
	}

	public void setWrapperCacheSize(int cacheSize) {
		this.wrapperCache.setCachePreferredMaxSize(cacheSize);
		int updatedCacheSize = this.getBeanIdCacheSize(cacheSize);
		this.beanIdCache.setSize(updatedCacheSize);
	}

	private int getBeanIdCacheSize(int cacheSize) {
		int beanIdCacheSize;
		if (cacheSize < 1073741823) {
			beanIdCacheSize = cacheSize * 2;
		} else {
			beanIdCacheSize = Integer.MAX_VALUE;
		}

		return beanIdCacheSize;
	}

	public boolean preInvoke(EJSWrapperBase wrapper) throws CSIException, RemoteException {
		if (wrapper.ivCommon.pinned > 0) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "preInvoke : pinned = false (already pinned)", wrapper);
			}

			return false;
		} else {
			boolean pinned = wrapper.ivCommon.pinOnce();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "preInvoke : pinned = " + pinned, wrapper);
			}

			return pinned;
		}
	}

	public void postInvoke(EJSWrapperBase wrapper) throws CSIException, RemoteException {
		wrapper.ivCommon.unpin();
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "postInvoke : unpinned", wrapper);
		}

	}

	public EJSWrapperCommon createWrapper(StatefulBeanO beanO) throws CSIException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createWrapper: " + beanO.getId());
		}

		BeanId id = beanO.getId();
		EJSHome home = beanO.home;
		ByteArray wrapperKey = id.getByteArray();
		wrapperKey.setBeanId(id);

		EJSWrapperCommon wc;
		try {
			wc = home.internalCreateWrapper(id);
		} catch (Exception var8) {
			FFDCFilter.processException(var8, "com.ibm.ejs.container.WrapperManager.createWrapper", "294", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Malformed object key", var8);
			}

			throw new CSIException("Wrapper creation failure: " + var8, var8);
		}

		wc.ivCachedBeanO = beanO;
		this.wrapperCache.insertUnpinned(wrapperKey, wc);
		this.beanIdCache.add(id);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createWrapper");
		}

		return wc;
	}

	public EJSWrapperCommon getWrapperForCreate(BeanO beanO) throws CSIException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getWrapperForCreate");
		}

		BeanId id = beanO.getId();
		EJSHome home = beanO.home;
		EJSWrapperCommon wc;
		if (home.statefulSessionHome) {
			wc = ((StatefulBeanO) beanO).ivWrapperCommon;
			if (wc == null) {
				wc = this.getWrapper(id);
			}
		} else {
			wc = this.getWrapper(id);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getWrapperForCreate");
		}

		return wc;
	}

	public EJSWrapperCommon getWrapper(BeanId id) throws CSIException, RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getWrapper");
		}

		EJSWrapperCommon result = null;
		if (id.byteArray == null && !id._isHome && id.pkey != null) {
			id = this.beanIdCache.find(id);
		}

		ByteArray wrapperKey = id.getByteArray();
		wrapperKey.setBeanId(id);

		try {
			result = (EJSWrapperCommon) this.wrapperCache.findAndFault(wrapperKey);
		} catch (FaultException var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.WrapperManager.getWrapper", "259", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Unable to fault in wrapper", var5);
			}

			throw new CSIException(var5.toString());
		}

		if (!id._isHome && id.pkey != null) {
			this.beanIdCache.add(result.getBeanId());
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getWrapper");
		}

		return result;
	}

	public boolean unregister(BeanId beanId, boolean dropRef) throws CSIException {
		boolean removed = false;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "unregister", new Object[]{beanId, new Boolean(dropRef)});
		}

		ByteArray wrapperKey = beanId.getByteArray();

		try {
			EJSWrapperCommon wrapperCommon = (EJSWrapperCommon) this.wrapperCache.removeAndDiscard(wrapperKey, dropRef);
			if (wrapperCommon != null) {
				removed = true;
			}
		} catch (IllegalOperationException var6) {
			FFDCFilter.processException(var6, "com.ibm.ejs.container.WrapperManager.unregister", "351", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "unregister ignoring IllegalOperationException for object " + beanId);
				Tr.event(tc, "Exception: " + var6);
			}
		} catch (DiscardException var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.container.WrapperManager.unregister", "358", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Unable to discard element");
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "unregister");
		}

		return removed;
	}

	public void unregisterHome(J2EEName homeName, EJSHome homeObj) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "unregisterHome");
		}

		int numEnumerated = 0;
		int numRemoved = 0;
		Enumeration enumerate = this.wrapperCache.enumerateElements();

		while (true) {
			J2EEName cacheHomeName;
			BeanId cacheMemberBeanId;
			do {
				if (!enumerate.hasMoreElements()) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Unregistered " + numRemoved + " wrappers (total = " + numEnumerated + ")");
					}

					this.beanIdCache.removeAll(homeObj);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.exit(tc, "unregisterHome");
					}

					return;
				}

				EJSWrapperCommon wCommon = (EJSWrapperCommon) ((CacheElement) enumerate.nextElement()).getObject();
				cacheMemberBeanId = wCommon.getBeanId();
				cacheHomeName = cacheMemberBeanId.getJ2EEName();
				++numEnumerated;
			} while (!cacheHomeName.equals(homeName) && !cacheMemberBeanId.equals(homeObj.getId()));

			this.unregister(cacheMemberBeanId, true);
			++numRemoved;
		}
	}

	public void discardObject(EJBCache wrapperCache, Object key, Object ele) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "discardObject", new Object[]{key, ele});
		}

		EJSWrapperCommon wrapperCommon = (EJSWrapperCommon) ele;
		wrapperCommon.disconnect();
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "discardObject");
		}

	}

	public Object keyToObject(byte[] key) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "keyToObject");
		}

		EJSWrapperCommon wc = null;
		Object wrapper = null;

		try {
			if (key[0] == -83) {
				WrapperId wrapperId = new WrapperId(key);
				ByteArray wrapperKey = wrapperId.getBeanIdArray();
				wc = (EJSWrapperCommon) this.wrapperCache.findAndFault(wrapperKey);
				if (wc != null) {
					wrapper = wc.getRemoteBusinessWrapper(wrapperId);
					BeanId beanId = ((EJSWrapperBase) wrapper).beanId;
					if (!beanId._isHome && beanId.pkey != null) {
						this.beanIdCache.add(beanId);
					}
				}
			} else {
				ByteArray wrapperKey = new ByteArray(key);
				wc = (EJSWrapperCommon) this.wrapperCache.findAndFault(wrapperKey);
				if (wc != null) {
					wrapper = wc.getRemoteObject();
					BeanId beanId = ((EJSWrapperBase) wrapper).beanId;
					if (!beanId._isHome && beanId.pkey != null) {
						this.beanIdCache.add(beanId);
					}
				}
			}
		} catch (FaultException var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.container.WrapperManager.keyToObject", "501", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Unable to fault in wrapper", var7);
			}

			throw new RemoteException(var7.getMessage(), var7);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "keyToObject", wrapper);
		}

		return wrapper;
	}

	public Object faultOnKey(EJBCache cache, Object key) throws FaultException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "faultOnKey", key);
		}

		ByteArray wrapperKey = (ByteArray) key;
		EJSWrapperCommon result = null;
		BeanId beanId = wrapperKey.getBeanId();

		try {
			if (beanId == null) {
				beanId = BeanId.getBeanId(wrapperKey, this.container);
			}

			result = this.container.createWrapper(beanId);
		} catch (InvalidBeanIdException var8) {
			FFDCFilter.processException(var8, "com.ibm.ejs.container.WrapperManager.faultOnKey", "533", this);
			Throwable cause = var8.getCause();
			if (cause instanceof EJBNotFoundException) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Application Not Started", var8);
				}

				throw new FaultException((EJBNotFoundException) cause, "Application not started or not installed");
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Malformed object key", var8);
			}

			throw new FaultException(var8, "Malformed object key");
		} catch (Exception var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.container.WrapperManager.faultOnKey", "548", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Malformed object key", var9);
			}

			throw new FaultException(var9, "Malformed object key");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "faultOnKey");
		}

		return result;
	}

	public byte[] getJ2EENameBytes(byte[] servantKey) throws CSIException {
		EJBOAKeyImpl key = new EJBOAKeyImpl(servantKey);
		return key.getJ2EENameBytes();
	}

	public void dump() {
		this.introspect(new TrDumpWriter(tc));
	}

	public void introspect(IntrospectionWriter writer) {
		writer.println();
		writer.printHeading(1, "WrapperManager");
		this.beanIdCache.introspect(writer);
		((Cache) this.wrapperCache).introspect(writer);
	}
}