package com.ibm.icu.text;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class CharsetMatch implements Comparable<CharsetMatch> {
	public static final int ENCODING_SCHEME = 1;
	public static final int BOM = 2;
	public static final int DECLARED_ENCODING = 4;
	public static final int LANG_STATISTICS = 8;
	private int fConfidence;
	private CharsetRecognizer fRecognizer;
	private byte[] fRawInput = null;
	private int fRawLength;
	private InputStream fInputStream = null;

	public Reader getReader() {
		InputStream inputStream = this.fInputStream;
		if (inputStream == null) {
			inputStream = new ByteArrayInputStream(this.fRawInput, 0, this.fRawLength);
		}

		try {
			((InputStream) inputStream).reset();
			return new InputStreamReader((InputStream) inputStream, this.getName());
		} catch (IOException var3) {
			return null;
		}
	}

	public String getString() throws IOException {
		return this.getString(-1);
	}

	public String getString(int maxLength) throws IOException {
		String result = null;
		if (this.fInputStream == null) {
			result = new String(this.fRawInput, this.getName());
			return result;
		} else {
			StringBuilder sb = new StringBuilder();
			char[] buffer = new char[1024];
			Reader reader = this.getReader();
			int max = maxLength < 0 ? Integer.MAX_VALUE : maxLength;

			int bytesRead;
			for (boolean var7 = false; (bytesRead = reader.read(buffer, 0,
					Math.min(max, 1024))) >= 0; max -= bytesRead) {
				sb.append(buffer, 0, bytesRead);
			}

			reader.close();
			return sb.toString();
		}
	}

	public int getConfidence() {
		return this.fConfidence;
	}

	public int getMatchType() {
		return 0;
	}

	public String getName() {
		return this.fRecognizer.getName();
	}

	public String getLanguage() {
		return this.fRecognizer.getLanguage();
	}

	public int compareTo(CharsetMatch other) {
		int compareResult = 0;
		if (this.fConfidence > other.fConfidence) {
			compareResult = 1;
		} else if (this.fConfidence < other.fConfidence) {
			compareResult = -1;
		}

		return compareResult;
	}

	CharsetMatch(CharsetDetector det, CharsetRecognizer rec, int conf) {
		this.fRecognizer = rec;
		this.fConfidence = conf;
		if (det.fInputStream == null) {
			this.fRawInput = det.fRawInput;
			this.fRawLength = det.fRawLength;
		}

		this.fInputStream = det.fInputStream;
	}
}