package com.ibm.ws.wim.config;

import com.ibm.ws.wim.util.DataGraphHelper;
import commonj.sdo.DataObject;

public class GenericHelperConfigHelper {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";

	public void resetIdMgrConfig(String var1) throws Exception {
		ConfigUtils.resetConfig(var1);
	}

	public DataObject showIdMgrConfig(String var1, String var2) throws Exception {
		DataObject var3 = (DataObject) ConfigSessionManager.singleton().getConfig(var1);
		if (var2 != null && var3 != null) {
			DataGraphHelper.saveDataGraph(var3.getDataGraph(), var2);
		}

		return var3;
	}
}