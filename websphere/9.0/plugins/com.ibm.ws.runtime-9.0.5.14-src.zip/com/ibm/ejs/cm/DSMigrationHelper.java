package com.ibm.ejs.cm;

import java.util.Properties;
import org.w3c.dom.Element;

public interface DSMigrationHelper {
	Properties migrateDataSourcesXML(String var1, Element var2);

	Properties migrateDataSource(String var1, String var2, String var3, String var4);

	Properties migrateAdminDotConfig(String var1, String var2, String var3, String var4, String var5);

	String[] convertUrlToUrlPrefixAndDatabaseName(String var1, String var2);
}