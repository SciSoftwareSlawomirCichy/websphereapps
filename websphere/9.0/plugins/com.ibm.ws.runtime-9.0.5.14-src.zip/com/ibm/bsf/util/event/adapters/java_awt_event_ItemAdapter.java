package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class java_awt_event_ItemAdapter extends EventAdapterImpl implements ItemListener {
	public void itemStateChanged(ItemEvent var1) {
		this.eventProcessor.processEvent("itemStateChanged", new Object[]{var1});
	}
}