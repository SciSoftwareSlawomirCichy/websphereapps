package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.ras.WIMLogger;
import com.sun.jndi.ldap.LdapName;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;

public class TimedDirContext extends InitialLdapContext {
	private static final String CLASSNAME = TimedDirContext.class.getName();
	private static final Logger trcLogger;
	private long iCreateTimestamp;
	private long iPoolTimestamp;
	private LdapConfigManager iLdapConfigMgr;

	public TimedDirContext() throws NamingException {
		this.iLdapConfigMgr = null;
	}

	public TimedDirContext(Hashtable var1, Control[] var2) throws NamingException {
		this(var1, var2, (LdapConfigManager) null);
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "init",
					"LdapConfigManager not set, DomainNameForAutomaticDiscoveryOfLDAPServers may not work");
		}

	}

	public TimedDirContext(Hashtable var1, Control[] var2, LdapConfigManager var3) throws NamingException {
		super(var1, var2);
		this.iLdapConfigMgr = null;
		this.iCreateTimestamp = System.currentTimeMillis() / 1000L;
		this.iPoolTimestamp = this.iCreateTimestamp;
		this.iLdapConfigMgr = var3;
	}

	public TimedDirContext(Hashtable var1, Control[] var2, long var3) throws NamingException {
		this(var1, var2, var3, (LdapConfigManager) null);
	}

	public TimedDirContext(Hashtable var1, Control[] var2, long var3, LdapConfigManager var5) throws NamingException {
		super(var1, var2);
		this.iLdapConfigMgr = null;
		this.iCreateTimestamp = var3;
		this.iPoolTimestamp = var3;
		this.iLdapConfigMgr = var5;
	}

	public long getCreateTimestamp() {
		return this.iCreateTimestamp;
	}

	public long getPoolTimestamp() {
		return this.iPoolTimestamp;
	}

	public void setPoolTimeStamp(long var1) {
		this.iPoolTimestamp = var1;
	}

	public void setCreateTimestamp(long var1) {
		this.iCreateTimestamp = var1;
	}

	private Name checkForDNSOverlap(Name var1) {
		if (this.iLdapConfigMgr != null
				&& this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers() != null) {
			try {
				var1 = new LdapName(this.checkForDNSOverlap(var1.toString()));
			} catch (InvalidNameException var3) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "checkForDNSOverlap",
							"Failed to create override name on " + var1.toString() + ": " + var3.getMessage());
				}
			}
		}

		return (Name) var1;
	}

	private String checkForDNSOverlap(String var1) {
		if (this.iLdapConfigMgr != null
				&& this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers() != null) {
			String var2 = var1.toLowerCase();
			String var3 = this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServersLowerCase();
			if (!var2.equals(var3) && !var3.endsWith(var2)) {
				if (var2.endsWith(var3)) {
					int var4 = var2.indexOf(var3);
					String var5 = var1;
					var1 = var1.substring(0, var4 - 1);
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "checkForDNSOverlap",
								"Override " + var5 + " with " + var1);
					}
				}
			} else {
				var1 = "";
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "checkForDNSOverlap",
							"Override " + var1 + " with empty. Domain is "
									+ this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers());
				}
			}
		}

		return var1;
	}

	public NamingEnumeration<SearchResult> search(Name var1, String var2, Object[] var3, SearchControls var4)
			throws NamingException {
		return super.search(this.checkForDNSOverlap(var1), var2, var3, var4);
	}

	public NamingEnumeration<SearchResult> search(Name var1, String var2, SearchControls var3) throws NamingException {
		return super.search(this.checkForDNSOverlap(var1), var2, var3);
	}

	public NamingEnumeration<SearchResult> search(String var1, String var2, Object[] var3, SearchControls var4)
			throws NamingException {
		return super.search(this.checkForDNSOverlap(var1), var2, var3, var4);
	}

	public NamingEnumeration<SearchResult> search(String var1, String var2, SearchControls var3)
			throws NamingException {
		return super.search(this.checkForDNSOverlap(var1), var2, var3);
	}

	public Attributes getAttributes(Name var1, String[] var2) throws NamingException {
		return super.getAttributes(this.checkForDNSOverlap(var1), var2);
	}

	public Attributes getAttributes(Name var1) throws NamingException {
		return super.getAttributes(this.checkForDNSOverlap(var1));
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}