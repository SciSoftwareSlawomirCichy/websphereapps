package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface GroupConfigurationType {
	List getMemberAttributes();

	MemberAttributesType[] getMemberAttributesAsArray();

	MemberAttributesType createMemberAttributes();

	List getDynamicMemberAttributes();

	DynamicMemberAttributesType[] getDynamicMemberAttributesAsArray();

	DynamicMemberAttributesType createDynamicMemberAttributes();

	MembershipAttributeType getMembershipAttribute();

	void setMembershipAttribute(MembershipAttributeType var1);

	MembershipAttributeType createMembershipAttribute();

	boolean isUpdateGroupMembership();

	void setUpdateGroupMembership(boolean var1);

	void unsetUpdateGroupMembership();

	boolean isSetUpdateGroupMembership();
}