package com.ibm.ffdc.util.provider;

interface package-info {
}