package com.ibm.ejs;

import java.io.PrintWriter;
import java.rmi.RemoteException;

public class EJSException extends RemoteException {
	public EJSException() {
	}

	public EJSException(String s) {
		super(s);
	}

	public EJSException(String s, Throwable ex) {
		super(s, ex);
	}

	public void printStackTrace(PrintWriter s) {
		super.printStackTrace(s);
	}
}