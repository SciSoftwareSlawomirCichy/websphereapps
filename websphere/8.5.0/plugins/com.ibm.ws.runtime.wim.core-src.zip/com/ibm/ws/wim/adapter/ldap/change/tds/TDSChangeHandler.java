package com.ibm.ws.wim.adapter.ldap.change.tds;

import com.ibm.websphere.wim.SchemaConstants;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.adapter.ldap.LdapConnection;
import com.ibm.ws.wim.adapter.ldap.LdapEntry;
import com.ibm.ws.wim.adapter.ldap.change.IChangeHandler;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;

public class TDSChangeHandler implements IChangeHandler, SchemaConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2009";
	private static final String CLASSNAME = TDSChangeHandler.class.getName();
	private static final Logger trcLogger;
	private final String ROOT_DSE_CHANGELOG_BASE = "cn=changelog";
	private final String ROOT_DSE_CHANGE_CHECKPOINT_ATTR = "lastChangeNumber";
	private final String CHANGETYPE_ATTR = "changeType";
	private final String CHANGENUMBER_ATTR = "changeNumber";
	private final String TARGETDN_ATTR = "targetDN";
	private final String NEWRDN = "newrdn";
	private final String NEWSUPERIOR = "newSuperior";
	private final String DEFAULT_LDAP_FILTER = "(objectclass=*)";
	private final String ROOT_DSE_BASE = "";
	private static final String TDS_CHANGETYPE_MODRDN = "modrdn";
	private static final String CHANGES = "changes";
	private LdapConnection _ldapConn;

	public TDSChangeHandler(LdapConnection var1) throws WIMException {
		this._ldapConn = var1;
	}

	public String getCurrentCheckPoint() throws WIMException {
		String var2 = null;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getCurrentCheckPoint");
		}

		try {
			NamingEnumeration var3 = this._ldapConn.search_skip_cache("", "(objectclass=*)", 0,
					new String[]{"lastChangeNumber"}, (Control[]) null);
			if (var3.hasMore()) {
				SearchResult var4 = (SearchResult) var3.next();
				Attribute var5 = var4.getAttributes().get("lastChangeNumber");
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getCurrentCheckPoint", "lastChangeNumAttr=" + var5);
				}

				if (var5 == null) {
					throw new OperationNotSupportedException("ERROR_IN_CHANGELOG_CONFIGURATION", Level.SEVERE,
							CLASSNAME, "getCurrentCheckPoint");
				}

				String var6 = (String) var5.get();
				int var7 = new Integer(var6) + 1;
				var2 = Integer.toString(var7);
			}
		} catch (NamingException var8) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var8.toString(true)),
					Level.SEVERE, CLASSNAME, "getCurrentCheckPoint");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getCurrentCheckPoint", "Checkpoint=" + var2);
		}

		return var2;
	}

	public List searchChangedEntities(String var1, List var2, String var3, String var4, int var5, List var6, List var7,
			int var8, int var9) throws WIMException {
		ArrayList var11 = null;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "searchChangedEntities", "CheckPoint=" + var1);
		}

		String var12 = "(targetDN=*" + var3 + ")";
		String var13 = "(changeNumber>=" + var1 + ")";
		StringBuffer var14 = null;
		if (var2 != null && var2.size() != 0 && !var2.contains("*")) {
			var14 = new StringBuffer("(|");

			for (int var15 = 0; var15 < var2.size(); ++var15) {
				if (var2.get(var15).toString().equalsIgnoreCase("rename")) {
					var14.append("(changeType=modrdn)");
				} else {
					var14.append("(changeType=" + var2.get(var15).toString() + ")");
				}
			}

			var14.append(")");
		} else {
			var14 = new StringBuffer("(changeType=*)");
		}

		StringBuffer var30 = new StringBuffer("(&" + var12 + var13);
		if (var14 != null) {
			var30.append(var14);
		}

		var30.append(")");
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities", "changeTypeFilter=" + var14);
		}

		try {
			NamingEnumeration var16 = this._ldapConn.search("cn=changelog", var30.toString(), 1,
					new String[]{"changeNumber", "changeType", "targetDN", "newrdn", "newSuperior", "changes"});
			if (var16.hasMore()) {
				var11 = new ArrayList();
			}

			Object var17 = null;
			String var18 = null;

			while (var16.hasMore()) {
				var17 = null;
				var18 = null;
				SearchResult var19 = (SearchResult) var16.next();
				Attributes var20 = var19.getAttributes();
				String var21 = var20.get("targetDN").get().toString();
				String var22 = var20.get("changeType").get().toString();
				String var23;
				if ("delete".equalsIgnoreCase(var22)) {
					if (var20.get("changes") != null) {
						var23 = var20.get("changes").get().toString();
						if (var23.indexOf(":") > -1) {
							var18 = var23.substring(var23.indexOf(":") + 1, var23.length()).trim();
						}
					}
				} else if ("modrdn".equalsIgnoreCase(var22)) {
					var22 = "rename";
					var23 = var20.get("newrdn").get().toString();
					String var24 = null;
					Attribute var25 = var20.get("newSuperior");
					if (var25 == null) {
						boolean var26 = true;

						int var34;
						do {
							do {
								var34 = var21.indexOf(",");
							} while (var34 == -1);
						} while (var21.charAt(var34 - 1) == '\\');

						var24 = var21.substring(var34);
					} else {
						var24 = var25.get().toString();
					}

					var21 = var23 + var24;
				}

				LdapEntry var31 = null;
				if (!"delete".equalsIgnoreCase(var22)) {
					try {
						Set var32 = this._ldapConn.searchEntities_skip_cache(var21, var4, 0, var6, var7, 1, var9,
								(Control[]) null);
						Iterator var33 = var32.iterator();
						if (var33.hasNext()) {
							var31 = (LdapEntry) var33.next();
							var31.setChangeType(var22);
						}
					} catch (EntityNotFoundException var27) {
						if ("rename".equalsIgnoreCase(var22)) {
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "searchChangedEntities",
										"adding the target DN for modrdn:" + var21);
							}

							var31 = new LdapEntry(var21, (String) null, (String) null, (String) null,
									(Attributes) null);
							var31.setChangeType("delete");
						}
					}
				} else {
					var31 = new LdapEntry(var21, var18, (String) null, (String) null, (Attributes) null);
					var31.setChangeType("delete");
				}

				if (var31 != null) {
					var11.add(var31);
				}
			}
		} catch (EntityNotFoundException var28) {
			throw new OperationNotSupportedException("ERROR_IN_CHANGELOG_CONFIGURATION", Level.SEVERE, CLASSNAME,
					"searchChangedEntities");
		} catch (NamingException var29) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var29.toString(true)),
					Level.SEVERE, CLASSNAME, "searchChangedEntities");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "searchChangedEntities",
					"Result set size = " + (var11 != null ? var11.size() : "0"));
		}

		return var11;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}