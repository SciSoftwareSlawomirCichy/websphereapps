package com.ibm.ejs.cm;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.advanced.cm.factory.CMFactoryException;
import com.ibm.websphere.advanced.cm.factory.DataSourceFactory;
import com.ibm.websphere.csi.EJBComponentMetaData;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.runtime.metadata.ContainerComponentMetaData;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import com.ibm.ws.webcontainer.metadata.WebComponentMetaData;
import com.ibm.ws.webcontainer.metadata.WebModuleMetaData;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import javax.naming.NamingException;
import javax.sql.DataSource;

public final class DSFactoryImpl implements DSFactory {
	private static Hashtable dataSources = new Hashtable();
	private static final TraceComponent tc = Tr.register(DSFactoryImpl.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public void shutdown() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "shutdown");
		}

		Hashtable var1 = dataSources;
		synchronized (dataSources) {
			Enumeration e = dataSources.elements();

			while (true) {
				if (!e.hasMoreElements()) {
					break;
				}

				((DataSourceImpl) e.nextElement()).destroy();
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "shutdown");
		}

	}

	public synchronized DataSource getDataSource(CMProperties cmProps)
			throws ClassNotFoundException, CMFactoryException {
		String datasourceName = cmProps.getName();
		DataSource ds = (DataSource) dataSources.get(datasourceName);
		if (ds != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Using cached DataSource");
			}
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Creating new DataSource");
			}

			ds = createDataSource(cmProps);
			Hashtable var4 = dataSources;
			synchronized (dataSources) {
				DataSource newds = (DataSource) dataSources.get(datasourceName);
				if (newds != null) {
					ds = newds;
				} else {
					dataSources.put(datasourceName, ds);
				}
			}
		}

		return ds;
	}

	public synchronized DataSource removeDataSource(String dataSourceName) {
		return (DataSource) dataSources.remove(dataSourceName);
	}

	private static DataSource createDataSource(CMProperties cmProps) throws ClassNotFoundException, CMFactoryException {
		DataSourceProperties dsProps = ((CMPropertiesImpl) cmProps).getDataSourceProperties();
		String driverType = dsProps.getProperty("driverType");
		if (DataSourceFactory.isRRSTransactional(cmProps, driverType)) {
			return createRRSTransactionalDataSource(cmProps);
		} else {
			return DataSourceFactory.isJTAEnabled(cmProps)
					? create2PhaseDataSource(cmProps)
					: create1PhaseDataSource(cmProps);
		}
	}

	private static DataSource create1PhaseDataSource(CMProperties attrs) throws CMFactoryException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "create1PhaseDataSource", attrs);
		}

		JDBC1PhaseRF ds = new JDBC1PhaseRF(attrs);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "create1PhaseDataSource", ds);
		}

		return ds;
	}

	private static DataSource create2PhaseDataSource(CMProperties attrs) throws CMFactoryException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "create2PhaseDataSource", attrs);
		}

		JDBC2PhaseRF ds = new JDBC2PhaseRF(attrs);
		DataSourceProperties tempProps = null;
		Properties xaRecoveryProps = ((CMPropertiesImpl) attrs).getXaRecoveryCredentials();
		if (xaRecoveryProps != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Replacing user and pwd with recovery user and pwd");
			}

			tempProps = (DataSourceProperties) ((CMPropertiesImpl) attrs).getDataSourceProperties().clone();
			tempProps.setProperty("user", (String) xaRecoveryProps.get("user"));
			tempProps.setProperty("password", (String) xaRecoveryProps.get("password"));
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "No recovery user and password, using default user and password");
			}

			tempProps = ((CMPropertiesImpl) attrs).getDataSourceProperties();
		}

		CMXAResourceInfo info = new CMXAResourceInfo(tempProps);
		ds.initialize(info, "com.ibm.ejs.cm.CMXAResourceFactory");
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "create2PhaseDataSource", ds);
		}

		return ds;
	}

	private static DataSource createRRSTransactionalDataSource(CMProperties attrs) throws CMFactoryException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createRRSTransactionalDataSource", attrs);
		}

		JDBCRRSTransactionalRF ds = new JDBCRRSTransactionalRF(attrs);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createRRSTransactionalDataSource", ds);
		}

		return ds;
	}

	public void verifyConfiguration() throws NamingException {
		ContainerComponentMetaData cmd = null;
		cmd = (ContainerComponentMetaData) ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor()
				.getComponentMetaData();
		if (cmd == null) {
			throw new IllegalStateException("Null ComponentMetaData");
		} else {
			if (cmd instanceof EJBComponentMetaData) {
				EJBComponentMetaData ejbCmd = (EJBComponentMetaData) cmd;
				int ejbModuleVersion = ejbCmd.getEJBModuleVersion();
				if (ejbModuleVersion >= 20) {
					Tr.error(tc, "MSG_CONM_7018E" + ejbModuleVersion);
					NamingException e = new NamingException(
							"Attempted to use a 4.0 DataSource in EJB 2.0 or higher Module. Invalid configuration.");
					FFDCFilter.processException(e, "com.ibm.ejs.DSFactoryImpl.verifyConfiguration", "%c%", this);
					throw e;
				}
			} else if (cmd instanceof WebComponentMetaData) {
				WebModuleMetaData webMmd = (WebModuleMetaData) cmd.getModuleMetaData();
				if (webMmd.isServlet23OrHigher()) {
					Tr.error(tc, "MSG_CONM_7019E");
					NamingException e = new NamingException(
							"Attempted to use a 4.0 DataSource from a 2.3 (or higher) servlet. Invalid configuration.");
					FFDCFilter.processException(e, "com.ibm.ejs.DSFactoryImpl.verifyConfiguration", "%c%", this);
					throw e;
				}
			}

		}
	}

	public static Enumeration getDataSources() {
		return dataSources == null ? null : dataSources.elements();
	}
}