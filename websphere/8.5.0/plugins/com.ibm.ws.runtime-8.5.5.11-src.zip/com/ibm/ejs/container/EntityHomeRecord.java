package com.ibm.ejs.container;

import com.ibm.websphere.cpmi.PMHomeInfo;

public interface EntityHomeRecord extends PMHomeInfo {
	boolean hasInheritance();
}