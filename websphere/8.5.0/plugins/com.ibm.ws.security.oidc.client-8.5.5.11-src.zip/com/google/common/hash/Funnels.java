package com.google.common.hash;

import com.google.common.annotations.Beta;
import com.google.common.hash.Funnels.ByteArrayFunnel;
import com.google.common.hash.Funnels.IntegerFunnel;
import com.google.common.hash.Funnels.LongFunnel;
import com.google.common.hash.Funnels.SinkAsStream;
import com.google.common.hash.Funnels.StringFunnel;
import java.io.OutputStream;

@Beta
public final class Funnels {
	public static Funnel<byte[]> byteArrayFunnel() {
		return ByteArrayFunnel.INSTANCE;
	}

	public static Funnel<CharSequence> stringFunnel() {
		return StringFunnel.INSTANCE;
	}

	public static Funnel<Integer> integerFunnel() {
		return IntegerFunnel.INSTANCE;
	}

	public static Funnel<Long> longFunnel() {
		return LongFunnel.INSTANCE;
	}

	public static OutputStream asOutputStream(PrimitiveSink sink) {
		return new SinkAsStream(sink);
	}
}