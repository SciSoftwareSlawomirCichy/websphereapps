package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.DataSourceProperties;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.sql.Connection;
import java.sql.SQLException;

public class PortabilityLayerFactory {
	private static final TraceComponent tc = Tr.register(PortabilityLayerFactory.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public static PortabilityLayer getPortabilityLayer(DataSourceProperties dsProps) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPortabilityLayer");
		}

		String dataSourceClassName = dsProps.getDataSourceClassName();
		PortabilityLayer pl = null;
		if (!dataSourceClassName.startsWith("COM.ibm.db2.jdbc.DB2")
				&& !dataSourceClassName.startsWith("com.ibm.db2.jcc.DB2")) {
			if (dataSourceClassName.startsWith("com.ibm.as400.access.AS400JDBC")) {
				pl = DB2AS400PortabilityLayer.getInstance(dsProps);
			} else if (!dataSourceClassName.startsWith("com.ibm.db2.jdbc.app.DB2Std")
					&& !dataSourceClassName.startsWith("com.ibm.db2.jdbc.app.UDB")) {
				if (dataSourceClassName.startsWith("oracle.jdbc.pool.Oracle")) {
					pl = OraclePortabilityLayer.getInstance(dsProps);
				} else if (dataSourceClassName.startsWith("oracle.jdbc.xa.client.Oracle")) {
					pl = OraclePortabilityLayer.getInstance(dsProps);
				} else if (dataSourceClassName.startsWith("com.informix.jdbcx.Ifx")) {
					pl = InformixPortabilityLayer.getInstance(dsProps);
				} else if (dataSourceClassName.startsWith("com.sybase.jdbc2.jdbc.Syb")) {
					pl = SybasePortabilityLayer.getInstance(dsProps);
				} else if (dataSourceClassName.startsWith("com.microsoft.sqlserver.jdbc.SQLServer")) {
					pl = MSSQLServerPortabilityLayer.getInstance(dsProps);
				} else if (!dataSourceClassName.startsWith("com.merant.sequelink.jdbcx.datasource.SequeLink")
						&& !dataSourceClassName.startsWith("com.ddtek.jdbcx.sequelink.SequeLink")
						&& !dataSourceClassName.startsWith("com.merant.datadirect.jdbcx.sqlserver.SQLServer")
						&& !dataSourceClassName.startsWith("com.ddtek.jdbcx.sqlserver.SQLServer")
						&& !dataSourceClassName.startsWith("com.microsoft.jdbcx.sqlserver.SQLServer")) {
					pl = GenericPortabilityLayer.getInstance(dsProps);
				} else {
					pl = MerantPortabilityLayer.getInstance(dsProps);
				}
			} else {
				pl = DB2AS400PortabilityLayer.getInstance(dsProps);
			}
		} else {
			pl = DB2PortabilityLayer.getInstance(dsProps);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getPortabilityLayer", pl);
		}

		return pl;
	}

	static PortabilityLayer getPortabilityLayer(String dataSourceClassName, Connection conn) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPortabilityLayer", dataSourceClassName);
		}

		PortabilityLayer pl = null;
		if (!dataSourceClassName.startsWith("com.merant.sequelink.jdbcx.datasource.SequeLink")
				&& !dataSourceClassName.startsWith("com.ddtek.jdbcx.sequelink.SequeLink")
				&& !dataSourceClassName.startsWith("com.merant.datadirect.jdbcx.sqlserver.SQLServer")
				&& !dataSourceClassName.startsWith("com.ddtek.jdbcx.sqlserver.SQLServer")
				&& !dataSourceClassName.startsWith("com.microsoft.jdbcx.sqlserver.SQLServer")) {
			if (dataSourceClassName.startsWith("oracle.jdbc.pool.Oracle")) {
				pl = OraclePortabilityLayer.getPortabilityLayer(conn);
			} else if (dataSourceClassName.startsWith("oracle.jdbc.xa.client.Oracle")) {
				pl = OraclePortabilityLayer.getPortabilityLayer(conn);
			} else if (dataSourceClassName.startsWith("com.informix.jdbcx.Ifx")) {
				pl = InformixPortabilityLayer.getPortabilityLayer(conn);
			} else if (dataSourceClassName.startsWith("com.sybase.jdbc2.jdbc.Syb")) {
				pl = SybasePortabilityLayer.getPortabilityLayer(conn);
			} else if (dataSourceClassName.startsWith("COM.ibm.db2.jdbc.DB2")) {
				pl = DB2PortabilityLayer.getPortabilityLayer(conn);
			} else if (dataSourceClassName.startsWith("com.ibm.as400.access.AS400JDBC")) {
				pl = DB2AS400PortabilityLayer.getPortabilityLayer(conn);
			} else if (!dataSourceClassName.startsWith("com.ibm.db2.jdbc.app.DB2Std")
					&& !dataSourceClassName.startsWith("com.ibm.db2.jdbc.app.UDB")) {
				if (dataSourceClassName.startsWith("com.ibm.db2.jcc.DB2")) {
					pl = DB2UniversalPortabilityLayer.getPortabilityLayer(conn);
				} else {
					pl = GenericPortabilityLayer.getPortabilityLayer(conn);
				}
			} else {
				pl = DB2AS400PortabilityLayer.getPortabilityLayer(conn);
			}
		} else {
			MerantPortabilityLayer.unlockJDBCDriver(conn, dataSourceClassName);
			pl = MerantPortabilityLayer.getPortabilityLayer(conn);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getPortabilityLayer", pl);
		}

		return pl;
	}
}