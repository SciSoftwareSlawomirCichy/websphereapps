package com.ibm.ejs.container;

public class CMP11CustomFinderAccIntentState {
	String methodName;
	boolean customFinderWithUpdateIntent;
	boolean readOnlyAttr;

	public CMP11CustomFinderAccIntentState(String mName, boolean cfwupdateintent, boolean readonly) {
		this.methodName = mName;
		this.customFinderWithUpdateIntent = cfwupdateintent;
		this.readOnlyAttr = readonly;
	}

	public boolean isCustomFinderWithUpdateIntent() {
		return this.customFinderWithUpdateIntent;
	}

	public boolean isReadOnly() {
		return this.readOnlyAttr;
	}

	public String getCustomFinderMethodname() {
		return this.methodName;
	}

	public String toString() {
		return "[" + this.methodName + " RO " + this.readOnlyAttr + " CFRO " + this.customFinderWithUpdateIntent + "]";
	}
}