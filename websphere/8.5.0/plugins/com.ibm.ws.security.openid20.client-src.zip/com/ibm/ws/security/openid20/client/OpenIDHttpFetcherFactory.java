package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.openid20.util.OidUtil;
import javax.net.ssl.SSLContext;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.openid4java.util.HttpFetcher;
import org.openid4java.util.HttpFetcherFactory;
import org.openid4java.util.HttpRequestOptions;

public class OpenIDHttpFetcherFactory extends HttpFetcherFactory {
	private static final TraceComponent tc = Tr.register(OpenIDHttpFetcherFactory.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private OpenIDClientConfig openidClientConfig = null;

	public OpenIDHttpFetcherFactory(SSLContext sslContext, OpenIDClientConfig openidClientConfig) {
		super(sslContext);
		this.openidClientConfig = openidClientConfig;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "OpenIDHttpFetcherFactory()");
		}

	}

	public OpenIDHttpFetcherFactory(SSLContext sslContext, X509HostnameVerifier hostnameVerifier,
			OpenIDClientConfig openidClientConfig) {
		super(sslContext, hostnameVerifier);
		this.openidClientConfig = openidClientConfig;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "OpenIDHttpFetcherFactory()");
		}

	}

	public HttpFetcher createFetcher(HttpRequestOptions defaultOptions) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createFetcher(defaultOptions[" + OidUtil.getObjState(defaultOptions) + "])");
		}

		defaultOptions.setSocketTimeout((int) this.openidClientConfig.getSocketTimeout());
		defaultOptions.setConnTimeout((int) this.openidClientConfig.getConnectTimeout());
		HttpFetcher hFetcher = super.createFetcher(defaultOptions);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createFetcher([" + OidUtil.getObjState(hFetcher) + "])");
		}

		return hFetcher;
	}
}