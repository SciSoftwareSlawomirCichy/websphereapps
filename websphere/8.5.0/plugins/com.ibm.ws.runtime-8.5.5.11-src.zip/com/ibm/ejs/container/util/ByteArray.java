package com.ibm.ejs.container.util;

import com.ibm.ejs.container.BeanId;

public final class ByteArray extends com.ibm.ejs.util.ByteArray {
	private BeanId beanId = null;
	private static final String CLASS_NAME = "com.ibm.ejs.container.util.ByteArray";

	public ByteArray(byte[] d) {
		super(d);
	}

	protected ByteArray() {
	}

	protected ByteArray(ByteArray b) {
		super(b);
		this.beanId = b.beanId;
	}

	public final void setBeanId(BeanId id) {
		this.beanId = id;
	}

	public final BeanId getBeanId() {
		return this.beanId;
	}
}