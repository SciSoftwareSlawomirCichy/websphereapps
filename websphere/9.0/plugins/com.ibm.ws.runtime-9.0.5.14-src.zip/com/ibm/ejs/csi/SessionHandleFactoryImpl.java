package com.ibm.ejs.csi;

import com.ibm.ejs.container.ContainerProperties;
import com.ibm.websphere.csi.StatefulSessionHandleFactory;
import com.ibm.ws.ejb.portable.HandleImpl;
import javax.ejb.EJBObject;
import javax.ejb.Handle;

public class SessionHandleFactoryImpl implements StatefulSessionHandleFactory {
	private static final boolean cvUsePortableClass;

	public synchronized Handle create(EJBObject object) {
		return (Handle) (cvUsePortableClass ? new HandleImpl(object) : new SessionHandle(object));
	}

	static {
		cvUsePortableClass = ContainerProperties.Portable;
	}
}