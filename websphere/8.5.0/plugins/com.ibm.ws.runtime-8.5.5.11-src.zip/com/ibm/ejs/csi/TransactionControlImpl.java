package com.ibm.ejs.csi;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.ContainerProperties;
import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.FastHashtable;
import com.ibm.tx.jta.embeddable.EmbeddableTransactionManagerFactory;
import com.ibm.websphere.csi.CSIActivitySessionResetException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.websphere.csi.TransactionAttribute;
import com.ibm.websphere.csi.TxContextChange;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.LocalTransaction.LocalTransactionCurrent;
import com.ibm.ws.LocalTransaction.RolledbackException;
import com.ibm.ws.Transaction.UOWCoordinator;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.traceinfo.ejbcontainer.TETxLifeCycleInfo;
import com.ibm.ws.tx.embeddable.EmbeddableWebSphereTransactionManager;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import javax.transaction.InvalidTransactionException;
import javax.transaction.Synchronization;
import javax.transaction.SystemException;
import javax.transaction.Transaction;
import javax.transaction.TransactionRolledbackException;
import javax.transaction.UserTransaction;

public class TransactionControlImpl implements UOWControl {
	private static final TraceComponent tc = Tr.register(TransactionControlImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.csi.TransactionControlImpl";
	protected EmbeddableWebSphereTransactionManager txService;
	protected UOWCurrent uowCurrent;
	protected LocalTransactionCurrent ltcCurrent;
	private TranStrategy[] txStrategies;
	private UserTransaction userTransactionImpl;
	FastHashtable<EJBKey, LocalTransactionCoordinator> stickyLocalTxTable = new FastHashtable(251);
	static final int TIMEOUT_CLOCK_START = 0;
	static final int TIMEOUT_CLOCK_STOP = 2;

	public TransactionControlImpl(UserTransaction userTx) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.txService = EmbeddableTransactionManagerFactory.getTransactionManager();
		this.ltcCurrent = EmbeddableTransactionManagerFactory.getLocalTransactionCurrent();
		this.uowCurrent = EmbeddableTransactionManagerFactory.getUOWCurrent();
		this.userTransactionImpl = userTx;
		this.txStrategies = new TranStrategy[TransactionAttribute.getNumAttrs()];
		this.txStrategies[TransactionAttribute.TX_NOT_SUPPORTED.getValue()] = new NotSupported(this);
		this.txStrategies[TransactionAttribute.TX_BEAN_MANAGED.getValue()] = new BeanManaged(this);
		this.txStrategies[TransactionAttribute.TX_REQUIRED.getValue()] = new Required(this);
		this.txStrategies[TransactionAttribute.TX_SUPPORTS.getValue()] = new Supports(this);
		this.txStrategies[TransactionAttribute.TX_REQUIRES_NEW.getValue()] = new RequiresNew(this);
		this.txStrategies[TransactionAttribute.TX_MANDATORY.getValue()] = new Mandatory(this);
		this.txStrategies[TransactionAttribute.TX_NEVER.getValue()] = new Never(this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public UOWCookie preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "preInvoke");
		}

		this.completeTxTimeout();
		TranStrategy ts = this.txStrategies[methodInfo.getTransactionAttribute().getValue()];
		TxCookieImpl txCookie = null;

		try {
			txCookie = ts.preInvoke(key, methodInfo);
		} catch (Throwable var8) {
			FFDCFilter.processException(var8, "com.ibm.ejs.csi.TransactionControlImpl.preInvoke", "266", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Tran Strategy preInvoke failed", var8);
			}

			if (var8 instanceof CSIException) {
				throw (CSIException) var8;
			}

			throw new CSIException("Tran Strategy preInvoke failed", var8);
		}

		txCookie.methodInfo = methodInfo;

		try {
			txCookie.ivCoordinator = this.getCurrentTransactionalUOW(false);
		} catch (Throwable var11) {
			FFDCFilter.processException(var11, "com.ibm.ejs.csi.TransactionControlImpl.preInvoke", "266", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "getCurrentTransactionalUOW failed", var11);
			}

			boolean ivFailPreinvoke = false;
			if (var11 instanceof CSITransactionRolledbackException
					&& methodInfo.getTransactionAttribute() == TransactionAttribute.TX_BEAN_MANAGED) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "BMT - allowing method to proceed");
				}

				try {
					txCookie.ivCoordinator = this.getCurrentTransactionalUOW(false);
				} catch (Throwable var10) {
					FFDCFilter.processException(var11, "com.ibm.ejs.csi.TransactionControlImpl.preInvoke", "386", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "BMT - failed trying to get Tran BMT bean in invalid state");
					}

					ivFailPreinvoke = true;
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "preInvoke (RolledBack) using old stuff : " + txCookie);
				}

				if (!ivFailPreinvoke) {
					return txCookie;
				}
			}

			try {
				this.postInvoke(key, txCookie, ExceptionType.UNCHECKED_EXCEPTION, methodInfo);
			} catch (Throwable var9) {
				FFDCFilter.processException(var9, "com.ibm.ejs.csi.TransactionControlImpl.preInvoke", "266", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "postInvoke failed : original exception re-thrown", var9);
				}
			}

			if (var11 instanceof CSIException) {
				throw (CSIException) var11;
			}

			throw new CSIException("getCurrentTransactionalUOW failed", var11);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "preInvoke : " + txCookie);
		}

		return txCookie;
	}

	public void postInvoke(EJBKey key, UOWCookie uowCookie, ExceptionType exType, EJBMethodInfoImpl methodInfo)
			throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "postInvoke");
		}

		TxCookieImpl txCookieImpl = (TxCookieImpl) uowCookie;
		if (txCookieImpl != null) {
			TranStrategy ts = txCookieImpl.txStrategy;
			boolean var22 = false;

			try {
				var22 = true;
				if (exType == ExceptionType.NO_EXCEPTION) {
					ts.postInvoke(key, txCookieImpl, methodInfo);
					var22 = false;
				} else {
					ts.handleException(key, txCookieImpl, exType, methodInfo);
					var22 = false;
				}
			} finally {
				if (var22) {
					LocalTransactionCoordinator suspendedLocalTx = txCookieImpl.suspendedLocalTx;
					if (suspendedLocalTx != null) {
						try {
							this.resumeLocalTx(suspendedLocalTx);
						} catch (Exception var25) {
							FFDCFilter.processException(var25, "com.ibm.ejs.csi.TransactionControlImpl.postInvoke",
									"394", this);
							if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
								Tr.event(tc, "Local tx resume failed", var25);
							}

							throw new CSIException("Local tx resume failed", var25);
						}
					} else {
						Transaction suspendedTx = txCookieImpl.suspendedTx;
						if (suspendedTx != null) {
							try {
								this.resumeGlobalTx(suspendedTx, 0);
							} catch (Exception var26) {
								FFDCFilter.processException(var26, "com.ibm.ejs.csi.TransactionControlImpl.postInvoke",
										"414", this);
								if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
									Tr.event(tc, "Global tx resume failed", var26);
								}

								throw new CSIException("Global tx resume failed", var26);
							}
						}
					}

				}
			}

			LocalTransactionCoordinator suspendedLocalTx = txCookieImpl.suspendedLocalTx;
			if (suspendedLocalTx != null) {
				try {
					this.resumeLocalTx(suspendedLocalTx);
				} catch (Exception var23) {
					FFDCFilter.processException(var23, "com.ibm.ejs.csi.TransactionControlImpl.postInvoke", "394",
							this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Local tx resume failed", var23);
					}

					throw new CSIException("Local tx resume failed", var23);
				}
			} else {
				Transaction suspendedTx = txCookieImpl.suspendedTx;
				if (suspendedTx != null) {
					try {
						this.resumeGlobalTx(suspendedTx, 0);
					} catch (Exception var28) {
						FFDCFilter.processException(var28, "com.ibm.ejs.csi.TransactionControlImpl.postInvoke", "414",
								this);
						if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
							Tr.event(tc, "Global tx resume failed", var28);
						}

						throw new CSIException("Global tx resume failed", var28);
					}
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "postInvoke");
			}

		} else {
			LocalTransactionCoordinator lCoord = this.getLocalCoord();
			if (lCoord != null) {
				try {
					int resolver = methodInfo.getBeanMetaData().getLocalTranConfigData().getValueResolver();
					if (resolver == 1) {
						lCoord.complete(1);
					} else {
						lCoord.setRollbackOnly();
						lCoord.cleanup();
					}
				} catch (RolledbackException var29) {
					FFDCFilter.processException(var29, "com.ibm.ejs.csi.TransactionControlImpl.postInvoke", "325",
							this);
				} catch (Throwable var30) {
					FFDCFilter.processException(var30, "com.ibm.ejs.csi.TransactionControlImpl.postInvoke", "330",
							this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Failed to complete local transaction", var30);
					}
				}

				throw new CSIException("Aborted improperly started local transaction");
			} else {
				try {
					this.setRollbackOnly();
				} catch (Throwable var24) {
					Throwable ex = var24;
					FFDCFilter.processException(var24, "com.ibm.ejs.csi.TransactionControlImpl.postInvoke", "345",
							this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Failed to mark global transaction for rollback", var24);
					}

					if (ContainerProperties.ExcludeNestedExceptions) {
						ex = null;
					}

					throw new CSITransactionRolledbackException("Rolled back improperly started global transaction",
							ex);
				}

				throw new CSITransactionRolledbackException("Rolled back improperly started global transaction");
			}
		}
	}

	public SynchronizationRegistryUOWScope getCurrentTransactionalUOW(boolean checkMarkedRollback)
			throws CSITransactionRolledbackException {
		UOWCoordinator coord = this.uowCurrent.getUOWCoord();
		if (coord != null && checkMarkedRollback && coord.getRollbackOnly()) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Attempting to do work on a tx that has been marked rollback.");
			}

			throw new CSITransactionRolledbackException("Transaction rolled back");
		} else {
			return (SynchronizationRegistryUOWScope) coord;
		}
	}

	public Object getCurrentSessionalUOW(boolean checkMarkedReset) throws CSIActivitySessionResetException {
		return null;
	}

	public UserTransaction getUserTransaction() {
		return this.userTransactionImpl;
	}

	public void setRollbackOnly() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "setRollbackOnly", this);
		}

		LocalTransactionCoordinator lCoord = this.getLocalCoord();
		if (lCoord != null) {
			lCoord.setRollbackOnly();
		} else {
			try {
				this.txService.setRollbackOnly();
			} catch (Exception var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.csi.TransactionControlImpl.setRollbackOnly", "556",
						this);
				throw new IllegalStateException("No active transaction");
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "setRollbackOnly");
		}

	}

	public boolean getRollbackOnly() {
		LocalTransactionCoordinator lCoord = this.getLocalCoord();
		if (lCoord != null) {
			return lCoord.getRollbackOnly();
		} else {
			int status = 6;

			try {
				status = this.txService.getStatus();
			} catch (SystemException var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.csi.TransactionControlImpl.getRollbackOnly", "667",
						this);
			}

			return status == 1 || status == 4 || status == 9;
		}
	}

	public void enlistWithTransaction(Synchronization sync) throws CSIException {
		SynchronizationRegistryUOWScope uowScope = this.getCurrentTransactionalUOW(false);
		if (uowScope == null) {
			throw new IllegalStateException("No active transaction");
		} else {
			this.enlistWithTransaction(uowScope, sync);
		}
	}

	public void enlistWithTransaction(SynchronizationRegistryUOWScope uowCoord, Synchronization sync)
			throws CSIException {
		try {
			if (uowCoord.getUOWType() == 1) {
				((Transaction) uowCoord).registerSynchronization(sync);
			} else {
				((LocalTransactionCoordinator) uowCoord).enlistSynchronization(sync);
			}

		} catch (Exception var4) {
			throw new CSIException("Failed to enlist with transaction", var4);
		}
	}

	public void enlistWithSession(Synchronization interestedParty) throws CSIException {
		throw new CSIException("ActivitySession should not exist");
	}

	public void sessionEnded(EJBKey[] EjbKeyArray) throws CSIException {
		throw new CSIException("ActivitySession should not exist");
	}

	public TxContextChange setupLocalTxContext(EJBKey key) throws CSIException {
		LocalTransactionCoordinator suspendedLocalTx = null;
		Transaction suspendedGlobalTx = null;
		LocalTransactionCoordinator activatedLocalTx = null;
		BeanMetaData bmd = ((BeanId) key).getHome().getBeanMetaData(key);
		int LocalTxBoundary = bmd.getLocalTranConfigData().getValueBoundary();
		Transaction globalTxCoord = this.getGlobalCoord();
		LocalTransactionCoordinator stickyLocalTx;
		if (globalTxCoord != null) {
			if (LocalTxBoundary == 1) {
				stickyLocalTx = (LocalTransactionCoordinator) this.stickyLocalTxTable.remove(key);
				if (stickyLocalTx != null) {
					try {
						suspendedGlobalTx = this.suspendGlobalTx(2);
					} catch (CSIException var10) {
						FFDCFilter.processException(var10, "com.ibm.ejs.csi.TransactionControlImpl.setupLocalTxContext",
								"937", this);
						this.stickyLocalTxTable.put(key, stickyLocalTx);
						throw var10;
					}

					this.resumeLocalTx(stickyLocalTx);
					activatedLocalTx = stickyLocalTx;
				}
			}
		} else {
			stickyLocalTx = this.getLocalCoord();
			LocalTransactionCoordinator stickyLocalTx = null;
			if (LocalTxBoundary == 1) {
				stickyLocalTx = (LocalTransactionCoordinator) this.stickyLocalTxTable.remove(key);
			}

			if (stickyLocalTx != null && stickyLocalTx != null) {
				this.suspendLocalTx();
				suspendedLocalTx = stickyLocalTx;
				this.resumeLocalTx(stickyLocalTx);
				activatedLocalTx = stickyLocalTx;
			} else if (stickyLocalTx == null && stickyLocalTx != null) {
				this.resumeLocalTx(stickyLocalTx);
				activatedLocalTx = stickyLocalTx;
			}
		}

		return new TxContextChange(suspendedLocalTx, suspendedGlobalTx, activatedLocalTx, key);
	}

	public void teardownLocalTxContext(TxContextChange changedContext) {
		LocalTransactionCoordinator activatedLocalTx = changedContext.getActivatedLocalTx();
		if (activatedLocalTx != null) {
			this.suspendLocalTx();
			this.stickyLocalTxTable.put(changedContext.getKey(), activatedLocalTx);
			LocalTransactionCoordinator previousLocalTx = changedContext.getSuspendedLocalTx();
			if (previousLocalTx != null) {
				this.resumeLocalTx(previousLocalTx);
			}

			Transaction previousGlobalTx = changedContext.getSuspendedGlobalTx();
			if (previousGlobalTx != null) {
				try {
					this.resumeGlobalTx(previousGlobalTx, 0);
				} catch (Exception var6) {
					FFDCFilter.processException(var6, "com.ibm.ejs.csi.TransactionControlImpl.teardownLocalTxContext",
							"650", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Global tx resume failed", var6);
					}
				}
			}
		}

	}

	final LocalTransactionCoordinator beginLocalTx() {
		LocalTransactionCoordinator lCoord = null;

		try {
			this.ltcCurrent.begin();
			lCoord = this.getLocalCoord();
			if (TraceComponent.isAnyTracingEnabled()) {
				if (tc.isEventEnabled()) {
					if (lCoord != null) {
						Tr.event(tc, "Began LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
					} else {
						Tr.event(tc, "Began LTC cntxt: null Coordinator!");
					}
				}

				if (lCoord != null && TETxLifeCycleInfo.isTraceEnabled()) {
					TETxLifeCycleInfo.traceLocalTxBegin("" + System.identityHashCode(lCoord), "Begin Local Tx");
				}
			}
		} catch (Exception var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.csi.TransactionControlImpl.beginLocalTx", "737", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Begin local tx failed", var3);
			}
		}

		return lCoord;
	}

	final LocalTransactionCoordinator suspendLocalTx() {
		LocalTransactionCoordinator lCoord = null;
		if (TraceComponent.isAnyTracingEnabled() && (tc.isEventEnabled() || TETxLifeCycleInfo.isTraceEnabled())) {
			lCoord = this.getLocalCoord();
			if (lCoord != null && TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Suspending LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
			}
		}

		LocalTransactionCoordinator rtnVal = this.ltcCurrent.suspend();
		if (lCoord != null && TraceComponent.isAnyTracingEnabled() && TETxLifeCycleInfo.isTraceEnabled()) {
			TETxLifeCycleInfo.traceLocalTxSuspend("" + System.identityHashCode(lCoord), "Suspend Local Tx");
		}

		return rtnVal;
	}

	final Transaction suspendGlobalTx(int action) throws CSIException {
		Transaction ctrl = null;

		try {
			ctrl = this.txService.suspend();
			if (TraceComponent.isAnyTracingEnabled()) {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "Suspending TX cntxt: " + ctrl);
				}

				if (TETxLifeCycleInfo.isTraceEnabled()) {
					String idStr = null;
					if (ctrl != null) {
						idStr = ctrl.toString();
					}

					int idx;
					idStr = idStr != null
							? ((idx = idStr.indexOf("(")) != -1
									? idStr.substring(idx + 1, idStr.indexOf(")"))
									: ((idx = idStr.indexOf("tid=")) != -1 ? idStr.substring(idx + 4) : idStr))
							: "NoTx";
					TETxLifeCycleInfo.traceGlobalTxSuspend(idStr, "Suspend Global Tx");
				}
			}
		} catch (SystemException var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.csi.TransactionControlImpl.setRollbackOnly", "770", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Error suspending global tx", var5);
			}

			throw new CSIException("suspend global tx failed", var5);
		}

		if (ctrl != null) {
			int txtype = ((UOWCoordinator) ctrl).getTxType();
			if (txtype == 2) {
				return ctrl;
			}
		}

		return ctrl;
	}

	final void resumeLocalTx(LocalTransactionCoordinator lCoord) throws IllegalStateException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			if (lCoord != null) {
				Tr.event(tc, "Resuming LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
			} else {
				Tr.event(tc, "Resuming LTC cntxt: null Coordinator!");
			}
		}

		this.ltcCurrent.resume(lCoord);
		if (TraceComponent.isAnyTracingEnabled() && lCoord != null && TETxLifeCycleInfo.isTraceEnabled()) {
			TETxLifeCycleInfo.traceLocalTxResume("" + System.identityHashCode(lCoord), "Resume Local Tx");
		}

	}

	final void resumeGlobalTx(Transaction ctrl, int action) throws SystemException, InvalidTransactionException {
		try {
			this.txService.resume(ctrl);
		} catch (SystemException var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.csi.TransactionControlImpl.resumeGlobalTx", "814", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Error resuming global tx", var5);
			}

			throw var5;
		}

		if (TraceComponent.isAnyTracingEnabled()) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "Resumed TX cntxt: " + this.txService.getTransaction());
			}

			if (TETxLifeCycleInfo.isTraceEnabled()) {
				String idStr = null;
				if (ctrl != null) {
					idStr = ctrl.toString();
				}

				int idx;
				idStr = idStr != null
						? ((idx = idStr.indexOf("(")) != -1
								? idStr.substring(idx + 1, idStr.indexOf(")"))
								: ((idx = idStr.indexOf("tid=")) != -1 ? idStr.substring(idx + 4) : idStr))
						: "NoTx";
				TETxLifeCycleInfo.traceGlobalTxResume(idStr, "Resume Global Tx");
			}
		}

		if (ctrl == null || ((UOWCoordinator) ctrl).getTxType() != 2) {
			;
		}
	}

	final LocalTransactionCoordinator getLocalCoord() {
		return this.ltcCurrent.getLocalTranCoord();
	}

	final Transaction getGlobalCoord() {
		try {
			Transaction control = this.txService.getTransaction();
			return control;
		} catch (SystemException var2) {
			FFDCFilter.processException(var2, "com.ibm.ejs.csi.TransactionControlImpl.getGlobalCoord", "856", this);
			Tr.warning(tc, "TRANSACTION_COORDINATOR_NOT_AVAILABLE_CNTR0022E", new Object[]{var2});
			return null;
		}
	}

	public final void completeTxTimeout() throws CSITransactionRolledbackException {
		try {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.entry(tc, "completeTxTimeout");
			}

			this.txService.completeTxTimeout();
		} catch (TransactionRolledbackException var2) {
			FFDCFilter.processException(var2, "com.ibm.ejs.csi.TransactionControlImpl.completeTxTimeout", "1390", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "completeTxTimeout throwing CSITransactionRolledBackException");
			}

			throw new CSITransactionRolledbackException("Transaction rolled back", var2);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "completeTxTimeout exit");
		}

	}

	public boolean isBmtActive(EJBMethodInfoImpl methodInfo) {
		TranStrategy ts = this.txStrategies[methodInfo.getTransactionAttribute().getValue()];
		return ts.isBmtActive();
	}

	public boolean isBmasActive(EJBMethodInfoImpl methodInfo) {
		return false;
	}

	public UOWHandle suspend() throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "suspend");
		}

		UOWHandle toReturn = null;
		if (this.getGlobalCoord() != null) {
			Transaction gtx = this.suspendGlobalTx(2);
			toReturn = new UOWHandleImpl(gtx);
		} else if (this.getLocalCoord() != null) {
			LocalTransactionCoordinator ltc = this.suspendLocalTx();
			toReturn = new UOWHandleImpl(ltc);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "suspend : " + toReturn);
		}

		return toReturn;
	}

	public void resume(UOWHandle handle) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "resume : " + handle);
		}

		if (handle != null) {
			UOWHandleImpl handleImpl = (UOWHandleImpl) handle;

			try {
				if (handleImpl.suspendedLocalTx != null) {
					this.resumeLocalTx(handleImpl.suspendedLocalTx);
				} else {
					this.resumeGlobalTx(handleImpl.suspendedGlobalTx, 0);
				}
			} catch (Throwable var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.csi.TransactionControlImpl.resume", "1491", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "resume", "Error resuming tx in TransactionControlImpl: " + var4);
				}

				throw new CSIException("Error resuming tx in TransactionControlImpl.", var4);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "resume");
		}

	}
}