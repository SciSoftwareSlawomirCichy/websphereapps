package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.CMProperties;
import com.ibm.ejs.cm.CMPropertiesImpl;
import com.ibm.ejs.cm.DataSourceProperties;
import com.ibm.ejs.cm.cache.CachedStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Properties;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;
import javax.sql.XAConnection;
import javax.sql.XADataSource;

public interface PortabilityLayer extends PortabilityLayerExt {
	int COLTYPE_ID = 0;
	int COLTYPE_SMALL_STRING = 1;
	int COLTYPE_NULLABLE_SMALL_STRING = 2;
	int COLTYPE_MEDIUM_STRING = 3;
	int COLTYPE_NULLABLE_MEDIUM_STRING = 4;
	int COLTYPE_BIG_STRING = 5;
	int COLTYPE_NULLABLE_BIG_STRING = 6;
	int COLTYPE_HUGE_STRING = 7;
	int COLTYPE_NULLABLE_HUGE_STRING = 8;
	int COLTYPE_HUGE_BYTEARRAY = 9;
	int COLTYPE_SMALL_BYTEARRAY = 10;
	int COLTYPE_MEDIUM_MEDIUM_STRING = 11;
	int COLTYPE_NULLABLE_MEDIUM_MEDIUM_STRING = 12;
	int COLTYPE_LAST_ENTRY = 13;
	int COLID_COSNAMING_NAME = 1;

	SQLException translateException(SQLException var1);

	SQLException translateException(SQLException var1, Hashtable var2);

	void createTable(Connection var1, String var2, String var3, String var4) throws SQLException;

	void createTable(Connection var1, String var2, String var3) throws SQLException;

	void createTableForPersister(Connection var1, String var2, String var3, String var4) throws SQLException;

	void setTransactionIsolation(Connection var1, int var2) throws SQLException;

	void setDate(PreparedStatement var1, int var2, Date var3, Calendar var4) throws SQLException;

	void setDate(PreparedStatement var1, int var2, Date var3) throws SQLException;

	void setTime(PreparedStatement var1, int var2, Time var3, Calendar var4) throws SQLException;

	void setTime(PreparedStatement var1, int var2, Time var3) throws SQLException;

	Date getDate(ResultSet var1, int var2, Calendar var3) throws SQLException;

	Date getDate(ResultSet var1, String var2, Calendar var3) throws SQLException;

	Date getDate(ResultSet var1, int var2) throws SQLException;

	Date getDate(ResultSet var1, String var2) throws SQLException;

	Time getTime(ResultSet var1, int var2, Calendar var3) throws SQLException;

	Time getTime(ResultSet var1, String var2, Calendar var3) throws SQLException;

	Time getTime(ResultSet var1, int var2) throws SQLException;

	Time getTime(ResultSet var1, String var2) throws SQLException;

	String scanSQL(String var1);

	String getColumnTypeSpec(int var1);

	String getNamedColumnSpec(int var1);

	Hashtable getErrorMap();

	ConnectionPoolDataSource getDataSource(DataSourceProperties var1) throws SQLException;

	XADataSource getXADataSource(DataSourceProperties var1) throws SQLException;

	Properties getDefaultDataSourceProps();

	String addRowLockHint(String var1);

	boolean supportsRowLockHint();

	boolean supportsSchema();

	void configureConnection(Connection var1, CMPropertiesImpl var2) throws SQLException;

	void configurePooledConnection(PooledConnection var1, CMProperties var2) throws SQLException;

	void configureXAConnection(XAConnection var1, CMProperties var2) throws SQLException;

	void setHugeStringForPreparedStatement(HugeString var1, PreparedStatement var2, int var3) throws SQLException;

	boolean checkCMPStoreOperation(String var1, Connection var2, boolean var3) throws SQLException;

	int getPreferredIsolationLevel();

	boolean supportsExtendedForUpdate(Connection var1) throws SQLException;

	Object extendedForUpdateInfo(Connection var1) throws SQLException;

	void resetStatement(CachedStatement var1) throws SQLException;

	String processSQLForExtendedUpdate(String var1, int var2);
}