package com.ibm.ejs.util;

interface package-info {
}