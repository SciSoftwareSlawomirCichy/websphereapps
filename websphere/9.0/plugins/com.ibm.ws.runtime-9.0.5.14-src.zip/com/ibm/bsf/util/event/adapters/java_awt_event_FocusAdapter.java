package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class java_awt_event_FocusAdapter extends EventAdapterImpl implements FocusListener {
	public void focusGained(FocusEvent var1) {
		this.eventProcessor.processEvent("focusGained", new Object[]{var1});
	}

	public void focusLost(FocusEvent var1) {
		this.eventProcessor.processEvent("focusLost", new Object[]{var1});
	}
}