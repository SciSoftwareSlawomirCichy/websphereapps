package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class AbstractMultimap<K, V> implements Multimap<K, V> {
	@MonotonicNonNullDecl
	private transient Collection<Entry<K, V>> entries;
	@MonotonicNonNullDecl
	private transient Set<K> keySet;
	@MonotonicNonNullDecl
	private transient Multiset<K> keys;
	@MonotonicNonNullDecl
	private transient Collection<V> values;
	@MonotonicNonNullDecl
	private transient Map<K, Collection<V>> asMap;

	public boolean isEmpty() {
		return this.size() == 0;
	}

	public boolean containsValue(@NullableDecl Object value) {
		Iterator var2 = this.asMap().values().iterator();

		Collection collection;
		do {
			if (!var2.hasNext()) {
				return false;
			}

			collection = (Collection) var2.next();
		} while (!collection.contains(value));

		return true;
	}

	public boolean containsEntry(@NullableDecl Object key, @NullableDecl Object value) {
		Collection<V> collection = (Collection) this.asMap().get(key);
		return collection != null && collection.contains(value);
	}

	@CanIgnoreReturnValue
	public boolean remove(@NullableDecl Object key, @NullableDecl Object value) {
		Collection<V> collection = (Collection) this.asMap().get(key);
		return collection != null && collection.remove(value);
	}

	@CanIgnoreReturnValue
	public boolean put(@NullableDecl K key, @NullableDecl V value) {
		return this.get(key).add(value);
	}

	@CanIgnoreReturnValue
	public boolean putAll(@NullableDecl K key, Iterable<? extends V> values) {
		Preconditions.checkNotNull(values);
		if (values instanceof Collection) {
			Collection<? extends V> valueCollection = (Collection) values;
			return !valueCollection.isEmpty() && this.get(key).addAll(valueCollection);
		} else {
			Iterator<? extends V> valueItr = values.iterator();
			return valueItr.hasNext() && Iterators.addAll(this.get(key), valueItr);
		}
	}

	@CanIgnoreReturnValue
	public boolean putAll(Multimap<? extends K, ? extends V> multimap) {
		boolean changed = false;

		Entry entry;
		for (Iterator var3 = multimap.entries().iterator(); var3
				.hasNext(); changed |= this.put(entry.getKey(), entry.getValue())) {
			entry = (Entry) var3.next();
		}

		return changed;
	}

	@CanIgnoreReturnValue
	public Collection<V> replaceValues(@NullableDecl K key, Iterable<? extends V> values) {
		Preconditions.checkNotNull(values);
		Collection<V> result = this.removeAll(key);
		this.putAll(key, values);
		return result;
	}

	public Collection<Entry<K, V>> entries() {
		Collection<Entry<K, V>> result = this.entries;
		return result == null ? (this.entries = this.createEntries()) : result;
	}

	abstract Collection<Entry<K, V>> createEntries();

	abstract Iterator<Entry<K, V>> entryIterator();

	public Set<K> keySet() {
		Set<K> result = this.keySet;
		return result == null ? (this.keySet = this.createKeySet()) : result;
	}

	abstract Set<K> createKeySet();

	public Multiset<K> keys() {
		Multiset<K> result = this.keys;
		return result == null ? (this.keys = this.createKeys()) : result;
	}

	abstract Multiset<K> createKeys();

	public Collection<V> values() {
		Collection<V> result = this.values;
		return result == null ? (this.values = this.createValues()) : result;
	}

	abstract Collection<V> createValues();

	Iterator<V> valueIterator() {
		return Maps.valueIterator(this.entries().iterator());
	}

	public Map<K, Collection<V>> asMap() {
		Map<K, Collection<V>> result = this.asMap;
		return result == null ? (this.asMap = this.createAsMap()) : result;
	}

	abstract Map<K, Collection<V>> createAsMap();

	public boolean equals(@NullableDecl Object object) {
		return Multimaps.equalsImpl(this, object);
	}

	public int hashCode() {
		return this.asMap().hashCode();
	}

	public String toString() {
		return this.asMap().toString();
	}
}